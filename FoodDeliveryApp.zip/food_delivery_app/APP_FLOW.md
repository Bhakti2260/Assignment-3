Food Delivery Application - Frontend Flow Documentation
Overview
This Flutter application is designed as the frontend for a food delivery service. It integrates Firebase Authentication for login/signup and then routes the user to a dashboard with a bottom navigation bar. The dashboard provides access to four main sections (pages):

Home: A welcome/dashboard page.
Orders: Displays a list of user orders.
Menu: Shows available food menu items.
Profile: Displays user profile details and allows logout.
Application Flow
1. Authentication Flow
   Login Page:
   Widgets: Text fields for email and password, a login button, and a navigation link to the signup page.
   Navigation: On successful login, navigates to the Dashboard.
   Signup Page:
   Widgets: Text fields for name, email, and password, a signup button, and a link back to the login page.
   Navigation: On successful signup, the user is automatically signed in and taken to the Dashboard.
2. Dashboard Flow (After Authentication)
   Bottom Navigation Bar:
   Pages: Home, Orders, Menu, Profile.
   Navigation: The bottom nav bar persists across the dashboard. Tapping on an icon switches between the respective pages.
   Home Page:
   Widgets: A welcome message and dashboard overview.
   Orders Page:
   Widgets: A list view displaying user orders.
   Navigation: Optionally, tapping an order could navigate to an Order Detail page (future expansion).
   Menu Page:
   Widgets: A list/grid view showing available menu items with images, descriptions, and prices.
   Profile Page:
   Widgets: User details (name, email, profile picture) and a logout button.
   Navigation: Logout button signs the user out and returns to the login page.
   Widgets and Navigation Details
   Scaffold: Each main page uses a Scaffold for consistent layout.
   AppBar: Provides a title and sometimes action buttons (e.g., logout on Profile).
   BottomNavigationBar: Used in the Dashboard to switch between pages.
   StreamBuilder (AuthenticationWrapper): Listens for Firebase auth state changes to determine if the user should see the login page or the dashboard.
   Routing:
   The main routes include /login, /signup, and /dashboard.
   The Dashboard page hosts the bottom navigation bar with internal routing to the four sections.