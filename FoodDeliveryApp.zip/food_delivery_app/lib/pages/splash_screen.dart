import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  AnimationController? _animationController;
  bool _isAnimationCompleted = false;
  bool _isAuthCheckComplete = false;
  String? _redirectRoute;

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3), // Adjust based on your animation duration
    );

    _animationController!.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        setState(() {
          _isAnimationCompleted = true;
        });
        _navigateIfReady();
      }
    });

    checkAuthStatus();
  }

  Future<void> checkAuthStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    final user = prefs.getString('user');

    setState(() {
      _redirectRoute = (user != null && user.isNotEmpty)
          ? '/dashboard'
          : '/login';
      _isAuthCheckComplete = true;
    });

    _navigateIfReady();
  }

  void _navigateIfReady() {
    if (_isAnimationCompleted && _isAuthCheckComplete && _redirectRoute != null) {
      Navigator.pushReplacementNamed(context, _redirectRoute!);
    }
  }

  @override
  void dispose() {
    _animationController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.asset(
              'assets/lottie/splash_screen.json',
              controller: _animationController,
              onLoaded: (composition) {
                // Configure the controller with the composition duration
                _animationController!
                  ..duration = composition.duration
                  ..forward();
              },
              width: MediaQuery.of(context).size.width,
              fit: BoxFit.contain,
            ),
            const SizedBox(height: 20),
            Text(
              "Food Delivery App",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary
              ),
            ),
          ],
        ),
      ),
    );
  }
}