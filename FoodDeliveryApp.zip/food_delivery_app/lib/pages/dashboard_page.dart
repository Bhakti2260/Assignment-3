import 'package:flutter/material.dart';
import 'package:food_delivery_app/pages/all_orders_page.dart';
import 'package:food_delivery_app/pages/profile_page.dart';
import 'package:food_delivery_app/pages/restaurants_page.dart';
import 'package:animations/animations.dart';

// Dummy Home page (replace with your actual page)
class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Home Page',
        style: TextStyle(fontSize: 24),
      ),
    );
  }
}

// Enhanced Dashboard with Material 3 components
class DashboardPage extends StatefulWidget {
  const DashboardPage({Key? key}) : super(key: key);

  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int _currentIndex = 0;

  // Page titles
  final List<String> _titles = const [
    'Food Delivery',
    'My Orders',
    'Restaurants',
    'Profile',
  ];

  // Pages to display
  final List<Widget> _pages = const [
    HomePage(),
    AllOrdersPage(),
    RestaurantsPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          _titles[_currentIndex],
          style: textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: _currentIndex != 0, // Center title except on home page
        backgroundColor: colorScheme.surface,
        elevation: 0,
        actions: [
          // Different actions based on current page
          if (_currentIndex == 0) // Home page actions
            IconButton(
              icon: Icon(Icons.search, color: colorScheme.primary),
              onPressed: () {
                // Implement search functionality
              },
            ),
          if (_currentIndex == 0) // Notifications on home page
            IconButton(
              icon: Icon(Icons.notifications_outlined, color: colorScheme.primary),
              onPressed: () {
                // Implement notifications
              },
            ),
          if (_currentIndex == 2) // Filter on restaurant page
            IconButton(
              icon: Icon(Icons.filter_list, color: colorScheme.primary),
              onPressed: () {
                // Implement filter
              },
            ),
        ],
      ),
      body: PageTransitionSwitcher(
        transitionBuilder: (child, primaryAnimation, secondaryAnimation) {
          return FadeThroughTransition(
            animation: primaryAnimation,
            secondaryAnimation: secondaryAnimation,
            child: child,
          );
        },
        child: _pages[_currentIndex],
      ),
      bottomNavigationBar: NavigationBar(
        onDestinationSelected: (int index) {
          setState(() {
            _currentIndex = index;
          });
        },
        selectedIndex: _currentIndex,
        backgroundColor: colorScheme.surface,
        indicatorColor: colorScheme.primaryContainer,
        labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
        elevation: 8,
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.home_outlined),
            selectedIcon: const Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: const Icon(Icons.receipt_outlined),
            selectedIcon: const Icon(Icons.receipt),
            label: 'Orders',
            tooltip: 'View your orders',
          ),
          NavigationDestination(
            icon: const Icon(Icons.restaurant_menu_outlined),
            selectedIcon: const Icon(Icons.restaurant_menu),
            label: 'Restaurants',
          ),
          NavigationDestination(
            icon: const Icon(Icons.person_outline),
            selectedIcon: const Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}