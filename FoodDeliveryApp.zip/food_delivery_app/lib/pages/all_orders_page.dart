import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/pages/order_details_page.dart';
import 'package:food_delivery_app/services/order_api_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

class AllOrdersPage extends StatefulWidget {
  const AllOrdersPage({Key? key}) : super(key: key);

  @override
  _AllOrdersPageState createState() => _AllOrdersPageState();
}

class _AllOrdersPageState extends State<AllOrdersPage> with TickerProviderStateMixin {
  bool isLoading = false;
  String error = '';
  List<dynamic> orders = [];
  List<dynamic> filteredOrders = [];
  final OrderApiService orderService = OrderApiService();
  late TabController _tabController;
  final List<String> _tabs = ['All', 'Active', 'Past'];
  String activeFilter = 'All';

  // Animation controllers
  late AnimationController _refreshIconController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _tabs.length, vsync: this);
    _tabController.addListener(_handleTabChange);
    _refreshIconController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    fetchOrders();
  }

  @override
  void dispose() {
    _tabController.removeListener(_handleTabChange);
    _tabController.dispose();
    _refreshIconController.dispose();
    super.dispose();
  }

  void _handleTabChange() {
    if (_tabController.indexIsChanging) {
      setState(() {
        activeFilter = _tabs[_tabController.index];
        _filterOrders();
      });
    }
  }

  void _filterOrders() {
    if (activeFilter == 'All') {
      filteredOrders = List.from(orders);
    } else if (activeFilter == 'Active') {
      filteredOrders = orders.where((order) {
        String status = order['status'].toString().toLowerCase();
        return ['pending', 'accepted', 'inpreparation'].contains(status);
      }).toList();
    } else {
      filteredOrders = orders.where((order) {
        String status = order['status'].toString().toLowerCase();
        return ['delivered', 'cancelled', 'completed'].contains(status);
      }).toList();
    }
  }

  Future<void> fetchOrders() async {
    setState(() {
      isLoading = true;
      error = '';
    });

    _refreshIconController.repeat();

    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? userJson = prefs.getString('user');
      if (userJson == null) {
        setState(() {
          error = "User not logged in.";
        });
        return;
      }

      final userMap = jsonDecode(userJson);
      final String customerId = userMap['id'];
      final fetchedOrders = await orderService.getOrdersByCustomer(customerId);

      // Sort orders by date (newest first)
      fetchedOrders.sort((a, b) {
        DateTime dateA = DateTime.parse(a['orderDate']);
        DateTime dateB = DateTime.parse(b['orderDate']);
        return dateB.compareTo(dateA);
      });

      setState(() {
        orders = fetchedOrders;
        _filterOrders();
      });
    } catch (e) {
      setState(() {
        error = e.toString();
      });
    } finally {
      setState(() {
        isLoading = false;
      });
      _refreshIconController.stop();
      _refreshIconController.reset();
    }
  }

  // Helper function to format date
  String _formatDate(String dateString) {
    try {
      final date = DateTime.parse(dateString);
      final now = DateTime.now();

      // If today, just show time
      if (date.year == now.year && date.month == now.month && date.day == now.day) {
        return 'Today, ${DateFormat('h:mm a').format(date)}';
      }

      // If yesterday
      final yesterday = now.subtract(const Duration(days: 1));
      if (date.year == yesterday.year && date.month == yesterday.month && date.day == yesterday.day) {
        return 'Yesterday, ${DateFormat('h:mm a').format(date)}';
      }

      // Otherwise show full date
      return DateFormat('MMM d, y • h:mm a').format(date);
    } catch (e) {
      return dateString;
    }
  }

  // Get status color and icon
  Map<String, dynamic> _getStatusInfo(String status) {
    final statusLower = status.toLowerCase();
    switch (statusLower) {
      case 'pending':
        return {
          'color': Colors.orange,
          'backgroundColor': Colors.orange.withOpacity(0.1),
          'icon': Icons.hourglass_empty,
        };
      case 'accepted':
        return {
          'color': Colors.blue,
          'backgroundColor': Colors.blue.withOpacity(0.1),
          'icon': Icons.thumb_up_alt_outlined,
        };
      case 'inpreparation':
        return {
          'color': Colors.amber,
          'backgroundColor': Colors.amber.withOpacity(0.1),
          'icon': Icons.restaurant_outlined,
        };
      case 'delivered':
        return {
          'color': Colors.green,
          'backgroundColor': Colors.green.withOpacity(0.1),
          'icon': Icons.check_circle_outline,
        };
      case 'completed':
        return {
          'color': Colors.green,
          'backgroundColor': Colors.green.withOpacity(0.1),
          'icon': Icons.check_circle,
        };
      case 'cancelled':
        return {
          'color': Colors.red,
          'backgroundColor': Colors.red.withOpacity(0.1),
          'icon': Icons.cancel_outlined,
        };
      default:
        return {
          'color': Colors.grey,
          'backgroundColor': Colors.grey.withOpacity(0.1),
          'icon': Icons.info_outline,
        };
    }
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            activeFilter == 'All' ? Icons.receipt_long_outlined :
            activeFilter == 'Active' ? Icons.local_shipping_outlined : Icons.history_outlined,
            size: 80,
            color: Theme.of(context).colorScheme.outline,
          ),
          const SizedBox(height: 16),
          Text(
            activeFilter == 'All' ? "You haven't placed any orders yet" :
            activeFilter == 'Active' ? "No active orders at the moment" : "No past orders found",
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: () {
              Navigator.pushReplacementNamed(context, '/dashboard');
            },
            icon: const Icon(Icons.restaurant_menu),
            label: const Text("Browse Restaurants"),
            style: FilledButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      body: Column(
        children: [
          // Tab bar for filtering
          Container(
            color: colorScheme.surface,
            child: TabBar(
              controller: _tabController,
              indicatorColor: colorScheme.primary,
              indicatorWeight: 3,
              labelColor: colorScheme.primary,
              unselectedLabelColor: colorScheme.onSurfaceVariant,
              tabs: _tabs.map((tab) => Tab(text: tab)).toList(),
            ),
          ),

          // Main content
          Expanded(
            child: RefreshIndicator(
              onRefresh: fetchOrders,
              color: colorScheme.primary,
              child: isLoading && orders.isEmpty
                  ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    RotationTransition(
                      turns: Tween(begin: 0.0, end: 1.0)
                          .animate(_refreshIconController),
                      child: Icon(Icons.refresh, size: 40, color: colorScheme.primary),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Loading your orders...',
                      style: TextStyle(color: colorScheme.onSurfaceVariant),
                    ),
                  ],
                ),
              )
                  : error.isNotEmpty
                  ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline, size: 48, color: colorScheme.error),
                    const SizedBox(height: 16),
                    Text(
                      error,
                      style: TextStyle(color: colorScheme.error),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 24),
                    OutlinedButton.icon(
                      onPressed: fetchOrders,
                      icon: const Icon(Icons.refresh),
                      label: const Text("Try Again"),
                    ),
                  ],
                ),
              )
                  : filteredOrders.isEmpty
                  ? _buildEmptyState()
                  : ListView.builder(
                padding: const EdgeInsets.symmetric(vertical: 8),
                itemCount: filteredOrders.length,
                itemBuilder: (context, index) {
                  var order = filteredOrders[index];
                  final statusInfo = _getStatusInfo(order['status'].toString());

                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    elevation: 2,
                    shadowColor: colorScheme.shadow.withOpacity(0.3),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                      side: BorderSide(
                        color: colorScheme.outlineVariant.withOpacity(0.2),
                        width: 1,
                      ),
                    ),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => OrderDetailsPage(orderId: order['id']),
                          ),
                        );
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Order header with status
                            Row(
                              children: [
                                Icon(Icons.restaurant, color: colorScheme.primary),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    order['restaurant']['name'] ?? 'Restaurant',
                                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                      fontWeight: FontWeight.bold,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: statusInfo['backgroundColor'],
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        statusInfo['icon'],
                                        size: 14,
                                        color: statusInfo['color'],
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        order['status'],
                                        style: TextStyle(
                                          color: statusInfo['color'],
                                          fontWeight: FontWeight.bold,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),

                            const SizedBox(height: 12),
                            const Divider(height: 1),
                            const SizedBox(height: 12),

                            // Order details
                            Row(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Order #${order['id']}',
                                      style: Theme.of(context).textTheme.bodyLarge,
                                    ),
                                    const SizedBox(height: 4),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.access_time,
                                          size: 16,
                                          color: colorScheme.onSurfaceVariant,
                                        ),
                                        const SizedBox(width: 4),
                                        Text(
                                          _formatDate(order['orderDate']),
                                          style: TextStyle(
                                            color: colorScheme.onSurfaceVariant,
                                            fontSize: 13,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                const Spacer(),
                                Text(
                                  '\$${order['totalAmount']?.toStringAsFixed(2) ?? '0.00'}',
                                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.bold,
                                    color: colorScheme.primary,
                                  ),
                                ),
                              ],
                            ),

                            // Order items preview
                            if (order['orderItems'] != null && (order['orderItems'] as List).isNotEmpty) ...[
                              const SizedBox(height: 12),
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: colorScheme.surfaceVariant.withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Items (${(order['orderItems'] as List).length})',
                                      style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        color: colorScheme.onSurfaceVariant,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      (order['orderItems'] as List)
                                          .take(2)
                                          .map((item) => '${item['quantity']}× ${item['menuItem']['name']}')
                                          .join(', ') +
                                          ((order['orderItems'] as List).length > 2
                                              ? ' and ${(order['orderItems'] as List).length - 2} more'
                                              : ''),
                                      style: TextStyle(
                                        fontSize: 13,
                                        color: colorScheme.onSurface,
                                      ),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                              ),
                            ],

                            const SizedBox(height: 12),

                            // Action row
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                TextButton.icon(
                                  onPressed: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => OrderDetailsPage(orderId: order['id']),
                                      ),
                                    );
                                  },
                                  icon: const Icon(Icons.receipt_outlined, size: 18),
                                  label: const Text('View Details'),
                                  style: TextButton.styleFrom(
                                    foregroundColor: colorScheme.primary,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}