import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:food_delivery_app/services/order_api_service.dart';
import 'package:food_delivery_app/services/menu_api_service.dart';
import 'package:food_delivery_app/core/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'order_details_page.dart';

class RestaurantDetailsPage extends StatefulWidget {
  final String restaurantId;
  const RestaurantDetailsPage({
    Key? key,
    required this.restaurantId,
  }) : super(key: key);

  @override
  _RestaurantDetailsPageState createState() => _RestaurantDetailsPageState();
}

class _RestaurantDetailsPageState extends State<RestaurantDetailsPage> with SingleTickerProviderStateMixin {
  bool isLoading = false;
  bool isLoadingRestaurant = false;
  bool isLoadingMenu = false;
  String error = '';
  Map<String, dynamic> restaurant = {};
  List<dynamic> menuItems = [];
  Map<String, List<dynamic>> categorizedMenu = {};
  List<String> categories = [];
  Map<int, int> cart = {};
  double cartTotal = 0.0;

  final MenuApiService _menuApiService = MenuApiService();
  final OrderApiService orderService = OrderApiService();
  late TabController _tabController;
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    fetchRestaurantDetails();
    fetchMenuItems();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> fetchRestaurantDetails() async {
    setState(() {
      isLoadingRestaurant = true;
      error = '';
    });

    try {
      Dio dio = createDio();
      Response response = await dio.get(
        "/api/Restaurants/${widget.restaurantId}",
        options: Options(
          headers: {"Content-Type": "application/json"},
        ),
      );

      if (response.statusCode == 200) {
        setState(() {
          restaurant = response.data;

          // Initialize tab controller after getting categories
          if (restaurant['menuCategories'] != null && (restaurant['menuCategories'] as List).isNotEmpty) {
            categories = List<String>.from((restaurant['menuCategories'] as List).map((e) => e.toString()));
            _tabController = TabController(length: categories.length + 1, vsync: this);

            // Categorize menu items once the restaurant data is loaded
            if (menuItems.isNotEmpty) {
              _categorizeMenuItems();
            }
          } else {
            categories = [];
            _tabController = TabController(length: 1, vsync: this);
          }
        });
      } else {
        setState(() {
          error = "Failed to load restaurant details. [${response.statusCode}]";
        });
      }
    } on DioException catch (e) {
      setState(() {
        error = "Error loading restaurant details: ${e.response?.data?.toString()}";
      });
    } catch (e) {
      setState(() {
        error = "Error loading restaurant details: $e";
      });
    } finally {
      setState(() {
        isLoadingRestaurant = false;
        isLoading = isLoadingRestaurant || isLoadingMenu;
      });
    }
  }

  Future<void> fetchMenuItems() async {
    setState(() {
      isLoadingMenu = true;
      error = '';
    });

    try {
      menuItems = await _menuApiService.getMenuByRestaurant(widget.restaurantId, page: 1, pageSize: 100);

      // Categorize menu items if restaurant data is already loaded
      if (restaurant.isNotEmpty && restaurant['menuCategories'] != null) {
        _categorizeMenuItems();
      }

    } on DioException catch (e) {
      setState(() {
        error = "Error loading menu: ${e.message}";
      });
    } catch (e) {
      setState(() {
        error = "Error loading menu: $e";
      });
    } finally {
      setState(() {
        isLoadingMenu = false;
        isLoading = isLoadingRestaurant || isLoadingMenu;
      });
    }
  }

  void _categorizeMenuItems() {
    categorizedMenu = {'All': []};

    // Initialize each category with an empty list
    for (var category in categories) {
      categorizedMenu[category] = [];
    }

    // Populate the categories
    for (var item in menuItems) {
      // Add to All category
      categorizedMenu['All']!.add(item);

      // Add to specific category
      String itemCategory = item['category'] ?? 'Uncategorized';
      if (categorizedMenu.containsKey(itemCategory)) {
        categorizedMenu[itemCategory]!.add(item);
      } else {
        // If category doesn't exist in our pre-defined list, add to uncategorized
        if (!categorizedMenu.containsKey('Uncategorized')) {
          categorizedMenu['Uncategorized'] = [];
        }
        categorizedMenu['Uncategorized']!.add(item);
      }
    }
  }

  void increaseQuantity(int menuItemId) {
    setState(() {
      cart[menuItemId] = (cart[menuItemId] ?? 0) + 1;
      _updateCartTotal();
    });
  }

  void decreaseQuantity(int menuItemId) {
    setState(() {
      int current = cart[menuItemId] ?? 0;
      if (current > 0) {
        cart[menuItemId] = current - 1;
      }
      _updateCartTotal();
    });
  }

  void removeItem(int menuItemId) {
    setState(() {
      cart[menuItemId] = 0;
      _updateCartTotal();
    });
  }

  void _updateCartTotal() {
    double total = 0.0;
    cart.forEach((id, quantity) {
      if (quantity > 0) {
        final item = menuItems.firstWhere(
                (item) => item['id'] == id,
            orElse: () => {'price': 0.0}
        );
        total += (item['price'] ?? 0.0) * quantity;
      }
    });
    cartTotal = total;
  }

  int getTotalItems() {
    int count = 0;
    cart.forEach((id, quantity) {
      count += quantity;
    });
    return count;
  }

  Future<void> placeOrder() async {
    // Build order payload from cart.
    List<Map<String, dynamic>> items = [];
    cart.forEach((id, quantity) {
      if (quantity > 0) {
        final item = menuItems.firstWhere(
                (item) => item['id'] == id,
            orElse: () => {'id': id, 'name': 'Unknown', 'price': 0.0}
        );

        items.add({
          'menuItemId': id,
          'quantity': quantity,
          'name': item['name'],
          'price': item['price']
        });
      }
    });

    if (items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Please add at least one item to your order."))
      );
      return;
    }

    setState(() {
      isLoading = true;
      error = '';
    });

    try {
      // Build order request payload.
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? userJson = prefs.getString('user');
      if (userJson == null) {
        setState(() {
          error = "User not found. Please log in again.";
        });
        return;
      }

      final userMap = jsonDecode(userJson);
      final String customerId = userMap['id'];

      Map<String, dynamic> orderRequest = {
        'restaurantId': widget.restaurantId,
        'customerId': customerId,
        'orderItems': items,
        'totalAmount': cartTotal,
        'status': 'Pending',
        'orderDate': DateTime.now().toIso8601String(),
        'specialInstructions': ''
      };

      // Call the API to create the order.
      final orderResponse = await orderService.createOrder(orderRequest);
      // Assume the response contains the new order's id in the 'id' property.
      final int orderId = orderResponse['id'];

      // Clear the cart.
      setState(() {
        cart = {};
        cartTotal = 0.0;
      });

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Order placed successfully!"),
            backgroundColor: Colors.green,
          )
      );

      // Navigate to the Order Details page.
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => OrderDetailsPage(orderId: orderId),
        ),
      );
    } catch (e) {
      setState(() {
        error = "Error placing order: $e";
      });

      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Failed to place order: $e"),
            backgroundColor: Colors.red,
          )
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  // Build restaurant info section
  Widget _buildRestaurantInfo() {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Restaurant image header
        Container(
          height: 200,
          width: double.infinity,
          child: CachedNetworkImage(
            imageUrl: "${getBaseUrl()}${restaurant['imageUrl'] ?? ''}",
            fit: BoxFit.cover,
            placeholder: (context, url) => Container(
              color: colorScheme.surfaceVariant,
              child: Center(child: CircularProgressIndicator()),
            ),
            errorWidget: (context, url, error) => Container(
              color: colorScheme.surfaceVariant,
              child: Icon(Icons.restaurant, size: 60, color: colorScheme.onSurfaceVariant),
            ),
          ),
        ),

        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Restaurant name and rating
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      restaurant['name'] ?? 'Restaurant',
                      style: textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  if (restaurant['rating'] != null)
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: colorScheme.primaryContainer,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.star, size: 16, color: colorScheme.onPrimaryContainer),
                          SizedBox(width: 4),
                          Text(
                            '${restaurant['rating']}',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: colorScheme.onPrimaryContainer,
                            ),
                          )
                        ],
                      ),
                    ),
                ],
              ),

              SizedBox(height: 8),

              // Cuisine and price range
              if (restaurant['cuisineType'] != null || restaurant['priceRange'] != null)
                Wrap(
                  spacing: 8,
                  children: [
                    if (restaurant['cuisineType'] != null)
                      Chip(
                        avatar: Icon(Icons.restaurant, size: 16),
                        label: Text(restaurant['cuisineType']),
                        visualDensity: VisualDensity.compact,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                    if (restaurant['priceRange'] != null)
                      Chip(
                        avatar: Icon(Icons.attach_money, size: 16),
                        label: Text(restaurant['priceRange']),
                        visualDensity: VisualDensity.compact,
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                  ],
                ),

              SizedBox(height: 16),

              // Opening hours
              if (restaurant['openingHours'] != null)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.access_time, color: colorScheme.primary),
                  title: Text('Opening Hours'),
                  subtitle: Text(restaurant['openingHours']),
                  dense: true,
                ),

              // Address
              if (restaurant['address'] != null)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.location_on, color: colorScheme.primary),
                  title: Text('Address'),
                  subtitle: Text(restaurant['address']),
                  dense: true,
                ),

              // Description
              if (restaurant['description'] != null && restaurant['description'].toString().isNotEmpty)
                Container(
                  margin: EdgeInsets.only(top: 16),
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: colorScheme.surfaceVariant.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'About',
                        style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 8),
                      Text(
                        restaurant['description'],
                        style: textTheme.bodyMedium,
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),

        Divider(thickness: 1),

        // Menu header
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            'Menu',
            style: textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }

  // Build menu item card
  Widget _buildMenuItemCard(dynamic menuItem, ColorScheme colorScheme) {
    bool isInCart = (cart[menuItem['id']] ?? 0) > 0;
    int quantity = cart[menuItem['id']] ?? 0;

    return Card(
      elevation: 0,
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 2),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: isInCart
              ? colorScheme.primary.withOpacity(0.5)
              : colorScheme.outlineVariant.withOpacity(0.3),
          width: isInCart ? 2 : 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Item image
            if (menuItem['imageUrl'] != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  width: 80,
                  height: 80,
                  child: CachedNetworkImage(
                    imageUrl: "${getBaseUrl()}${menuItem['imageUrl']}",
                    fit: BoxFit.cover,
                    placeholder: (context, url) => Container(
                      color: colorScheme.surfaceVariant,
                      child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
                    ),
                    errorWidget: (context, url, error) => Container(
                      color: colorScheme.surfaceVariant,
                      child: Icon(Icons.fastfood, color: colorScheme.onSurfaceVariant),
                    ),
                  ),
                ),
              ),

            SizedBox(width: menuItem['imageUrl'] != null ? 12 : 0),

            // Item details
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    menuItem['name'] ?? 'Menu Item',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  if (menuItem['description'] != null && menuItem['description'].toString().isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Text(
                        menuItem['description'],
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: colorScheme.onSurfaceVariant,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),

                  SizedBox(height: 8),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Price
                      Text(
                        '\$${(menuItem['price'] ?? 0).toStringAsFixed(2)}',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: colorScheme.primary,
                        ),
                      ),

                      // Quantity controls
                      Row(
                        children: [
                          if (isInCart)
                            Container(
                              decoration: BoxDecoration(
                                color: colorScheme.primaryContainer,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Row(
                                children: [
                                  IconButton(
                                    icon: Icon(Icons.remove, size: 16),
                                    constraints: BoxConstraints(minWidth: 36, minHeight: 36),
                                    padding: EdgeInsets.zero,
                                    onPressed: () => decreaseQuantity(menuItem['id']),
                                    color: colorScheme.primary,
                                  ),
                                  Text(
                                    '$quantity',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: colorScheme.onPrimaryContainer,
                                    ),
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.add, size: 16),
                                    constraints: BoxConstraints(minWidth: 36, minHeight: 36),
                                    padding: EdgeInsets.zero,
                                    onPressed: () => increaseQuantity(menuItem['id']),
                                    color: colorScheme.primary,
                                  ),
                                ],
                              ),
                            )
                          else
                            ElevatedButton(
                              onPressed: () => increaseQuantity(menuItem['id']),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: colorScheme.primaryContainer,
                                foregroundColor: colorScheme.onPrimaryContainer,
                                minimumSize: Size(36, 36),
                                padding: EdgeInsets.symmetric(horizontal: 12),
                              ),
                              child: Text('Add'),
                            ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final totalItems = getTotalItems();

    return Scaffold(
      appBar: AppBar(
        title: Text(restaurant['name'] ?? 'Restaurant Details'),
        actions: [
          if (!isLoading)
            IconButton(
              onPressed: () {
                fetchRestaurantDetails();
                fetchMenuItems();
              },
              icon: Icon(Icons.refresh),
              tooltip: 'Refresh',
            ),
        ],
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : error.isNotEmpty
          ? Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.error_outline, size: 60, color: colorScheme.error),
              SizedBox(height: 16),
              Text(
                error,
                style: TextStyle(color: colorScheme.error),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 24),
              FilledButton.icon(
                onPressed: () {
                  fetchRestaurantDetails();
                  fetchMenuItems();
                },
                icon: Icon(Icons.refresh),
                label: Text('Try Again'),
              ),
            ],
          ),
        ),
      )
          : restaurant.isEmpty
          ? Center(child: Text('Restaurant not found'))
          : Column(
        children: [
          // Menu content
          Expanded(
            child: categories.isEmpty
                ? SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildRestaurantInfo(),
                  // If no categories are defined, just show all menu items
                  menuItems.isEmpty
                      ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Column(
                        children: [
                          Icon(
                            Icons.no_meals,
                            size: 60,
                            color: colorScheme.outline,
                          ),
                          SizedBox(height: 16),
                          Text(
                            'No menu items available',
                            style: TextStyle(color: colorScheme.onSurfaceVariant),
                          ),
                        ],
                      ),
                    ),
                  )
                      : Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: menuItems
                          .map((item) => _buildMenuItemCard(item, colorScheme))
                          .toList(),
                    ),
                  ),
                ],
              ),
            )
                : NestedScrollView(
              headerSliverBuilder: (context, innerBoxIsScrolled) {
                return [
                  SliverToBoxAdapter(
                    child: _buildRestaurantInfo(),
                  ),
                  SliverOverlapAbsorber(
                    handle: NestedScrollView.sliverOverlapAbsorberHandleFor(context),
                    sliver: SliverPersistentHeader(
                      pinned: true,
                      delegate: _SliverAppBarDelegate(
                        TabBar(
                          controller: _tabController,
                          isScrollable: true,
                          tabAlignment: TabAlignment.start,
                          dividerColor: Colors.transparent,
                          tabs: [
                            Tab(text: 'All'),
                            ...categories.map((c) => Tab(text: c)).toList(),
                          ],
                          labelColor: colorScheme.primary,
                          unselectedLabelColor: colorScheme.onSurfaceVariant,
                          indicatorColor: colorScheme.primary,
                        ),
                        colorScheme.surface,
                      ),
                    ),
                  ),
                ];
              },
              body: TabBarView(
                controller: _tabController,
                children: [
                  // All items tab
                  _buildMenuTab('All', categorizedMenu['All'] ?? []),

                  // Category tabs
                  ...categories.map((category) =>
                      _buildMenuTab(category, categorizedMenu[category] ?? []),
                  ).toList(),
                ],
              ),
            ),
          ),

          // Cart summary bar
          AnimatedContainer(
            duration: Duration(milliseconds: 300),
            height: totalItems > 0 ? 72 : 0,
            child: totalItems > 0
                ? Container(
              color: colorScheme.primaryContainer,
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '$totalItems ${totalItems == 1 ? 'item' : 'items'}',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: colorScheme.onPrimaryContainer,
                        ),
                      ),
                      Text(
                        '\$${cartTotal.toStringAsFixed(2)}',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: colorScheme.onPrimaryContainer,
                          fontSize: 18,
                        ),
                      ),
                    ],
                  ),
                  Spacer(),
                  FilledButton.icon(
                    onPressed: placeOrder,
                    icon: Icon(Icons.shopping_cart_checkout),
                    label: Text('Place Order'),
                    style: FilledButton.styleFrom(
                      backgroundColor: colorScheme.primary,
                      foregroundColor: colorScheme.onPrimary,
                    ),
                  ),
                ],
              ),
            )
                : SizedBox.shrink(),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuTab(String category, List<dynamic> items) {
    final colorScheme = Theme.of(context).colorScheme;

    return items.isEmpty
        ? Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.no_meals,
              size: 60,
              color: colorScheme.outline,
            ),
            SizedBox(height: 16),
            Text(
              'No items in $category category',
              style: TextStyle(color: colorScheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    )
        : ListView.builder(
      padding: EdgeInsets.all(16),
      itemCount: items.length,
      itemBuilder: (context, index) {
        return _buildMenuItemCard(items[index], colorScheme);
      },
    );
  }
}

// Custom delegate for the tab bar
class _SliverAppBarDelegate extends SliverPersistentHeaderDelegate {
  _SliverAppBarDelegate(this._tabBar, this._backgroundColor);

  final TabBar _tabBar;
  final Color _backgroundColor;

  @override
  double get minExtent => _tabBar.preferredSize.height;
  @override
  double get maxExtent => _tabBar.preferredSize.height;

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: _backgroundColor,
      child: _tabBar,
    );
  }

  @override
  bool shouldRebuild(_SliverAppBarDelegate oldDelegate) {
    return false;
  }
}