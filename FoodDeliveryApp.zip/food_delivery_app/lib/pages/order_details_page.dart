import 'package:flutter/material.dart';
import 'package:food_delivery_app/services/order_api_service.dart';
import 'package:intl/intl.dart';
import 'package:timeline_tile/timeline_tile.dart';

class OrderDetailsPage extends StatefulWidget {
  final int orderId;
  const OrderDetailsPage({Key? key, required this.orderId}) : super(key: key);

  @override
  _OrderDetailsPageState createState() => _OrderDetailsPageState();
}

class _OrderDetailsPageState extends State<OrderDetailsPage> with SingleTickerProviderStateMixin {
  bool isLoading = false;
  bool isCancelling = false;
  String error = '';
  Map<String, dynamic>? order;
  final OrderApiService orderService = OrderApiService();
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeIn,
    );
    fetchOrder();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> fetchOrder() async {
    setState(() {
      isLoading = true;
      error = '';
    });
    try {
      final fetchedOrder = await orderService.getOrder(widget.orderId);
      setState(() {
        order = fetchedOrder;
      });
      _animationController.forward();
    } catch (e) {
      setState(() {
        error = "Failed to load order details: ${e.toString()}";
      });
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> cancelOrder() async {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Cancel Order'),
          content: const Text('Are you sure you want to cancel this order?'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('No'),
            ),
            FilledButton(
              onPressed: () async {
                Navigator.pop(context);
                try {
                  setState(() {
                    isCancelling = true;
                  });
                  await orderService.cancelOrder(widget.orderId);
                  await fetchOrder(); // Refresh order details
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text("Order cancelled successfully"),
                        backgroundColor: Colors.green,
                      ),
                    );
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Failed to cancel order: ${e.toString()}"),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                } finally {
                  setState(() {
                    isCancelling = false;
                  });
                }
              },
              child: const Text('Yes, Cancel Order'),
            ),
          ],
        );
      },
    );
  }

  // Format date nicely
  String _formatDate(String dateString) {
    try {
      DateTime date = DateTime.parse(dateString);
      return DateFormat('MMM d, y • h:mm a').format(date);
    } catch (e) {
      return dateString;
    }
  }

  // Get status indicator info
  Map<String, dynamic> _getStatusInfo(String status) {
    final statusLower = status.toLowerCase();
    switch (statusLower) {
      case 'pending':
        return {
          'color': Colors.orange,
          'backgroundColor': Colors.orange.withOpacity(0.1),
          'icon': Icons.hourglass_empty,
          'description': 'Your order is being reviewed by the restaurant',
        };
      case 'accepted':
        return {
          'color': Colors.blue,
          'backgroundColor': Colors.blue.withOpacity(0.1),
          'icon': Icons.thumb_up_alt_outlined,
          'description': 'The restaurant has accepted your order',
        };
      case 'inpreparation':
        return {
          'color': Colors.amber,
          'backgroundColor': Colors.amber.withOpacity(0.1),
          'icon': Icons.restaurant_outlined,
          'description': 'Your food is being prepared',
        };
      case 'delivered':
        return {
          'color': Colors.green,
          'backgroundColor': Colors.green.withOpacity(0.1),
          'icon': Icons.check_circle_outline,
          'description': 'Your order has been delivered',
        };
      case 'completed':
        return {
          'color': Colors.green,
          'backgroundColor': Colors.green.withOpacity(0.1),
          'icon': Icons.check_circle,
          'description': 'Your order has been completed',
        };
      case 'cancelled':
        return {
          'color': Colors.red,
          'backgroundColor': Colors.red.withOpacity(0.1),
          'icon': Icons.cancel_outlined,
          'description': 'This order was cancelled',
        };
      default:
        return {
          'color': Colors.grey,
          'backgroundColor': Colors.grey.withOpacity(0.1),
          'icon': Icons.info_outline,
          'description': 'Order status: $status',
        };
    }
  }

  // Calculate order timeline steps
  List<Map<String, dynamic>> _getOrderTimeline(String status) {
    final statusLower = status.toLowerCase();
    final List<Map<String, dynamic>> steps = [
      {
        'title': 'Order Placed',
        'isCompleted': true,
        'icon': Icons.receipt_outlined,
      },
      {
        'title': 'Order Accepted',
        'isCompleted': ['accepted', 'inpreparation', 'delivered', 'completed'].contains(statusLower),
        'icon': Icons.thumb_up_alt_outlined,
      },
      {
        'title': 'Preparing',
        'isCompleted': ['inpreparation', 'delivered', 'completed'].contains(statusLower),
        'icon': Icons.restaurant_outlined,
      },
      {
        'title': 'Out for Delivery',
        'isCompleted': ['delivered', 'completed'].contains(statusLower),
        'icon': Icons.delivery_dining_outlined,
      },
      {
        'title': 'Delivered',
        'isCompleted': ['delivered', 'completed'].contains(statusLower),
        'icon': Icons.check_circle_outline,
      },
    ];

    // Special case for cancelled orders
    if (statusLower == 'cancelled') {
      return [
        {
          'title': 'Order Placed',
          'isCompleted': true,
          'icon': Icons.receipt_outlined,
        },
        {
          'title': 'Order Cancelled',
          'isCompleted': true,
          'icon': Icons.cancel_outlined,
        },
      ];
    }

    return steps;
  }

  Widget _buildLoadingIndicator() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 16),
          Text(
            'Loading order details...',
            style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 60, color: Theme.of(context).colorScheme.error),
            SizedBox(height: 16),
            Text(
              error,
              style: TextStyle(color: Theme.of(context).colorScheme.error),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 24),
            OutlinedButton.icon(
              onPressed: fetchOrder,
              icon: Icon(Icons.refresh),
              label: Text("Try Again"),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: Text("Order Details", style: textTheme.titleLarge),
        elevation: 0,
        backgroundColor: colorScheme.surface,
        actions: [
          if (order != null && order!['status'].toString().toLowerCase() == 'pending' && !isCancelling)
            IconButton(
              icon: Icon(Icons.cancel_outlined, color: colorScheme.error),
              onPressed: cancelOrder,
              tooltip: 'Cancel Order',
            ),
        ],
      ),
      body: isLoading
          ? _buildLoadingIndicator()
          : error.isNotEmpty
          ? _buildErrorView()
          : order == null
          ? Center(child: Text("No order found"))
          : FadeTransition(
        opacity: _fadeAnimation,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Order ID and Date Section
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Order #${order!['id']}",
                            style: textTheme.headlineSmall?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            _formatDate(order!['orderDate']),
                            style: TextStyle(
                              color: colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Status Badge
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: _getStatusInfo(order!['status'])['backgroundColor'],
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            _getStatusInfo(order!['status'])['icon'],
                            size: 16,
                            color: _getStatusInfo(order!['status'])['color'],
                          ),
                          SizedBox(width: 6),
                          Text(
                            order!['status'],
                            style: TextStyle(
                              color: _getStatusInfo(order!['status'])['color'],
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 8),
                Text(
                  _getStatusInfo(order!['status'])['description'],
                  style: TextStyle(color: colorScheme.onSurfaceVariant),
                ),
                SizedBox(height: 24),

                // Restaurant Info Card
                Card(
                  elevation: 1,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(
                      color: colorScheme.outlineVariant.withOpacity(0.2),
                      width: 1,
                    ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          padding: EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: colorScheme.primaryContainer.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.restaurant,
                            color: colorScheme.primary,
                            size: 28,
                          ),
                        ),
                        SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                order!['restaurantName'] ?? 'Restaurant',
                                style: textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              if (order!['deliveryAddress'] != null)
                                Padding(
                                  padding: const EdgeInsets.only(top: 4.0),
                                  child: Text(
                                    'Delivery to: ${order!['deliveryAddress']}',
                                    style: TextStyle(
                                      color: colorScheme.onSurfaceVariant,
                                      fontSize: 13,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                SizedBox(height: 24),

                // Order Status Timeline
                Text(
                  "Order Status",
                  style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 16),
                Container(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    color: colorScheme.surfaceVariant.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: _getOrderTimeline(order!['status']).asMap().entries.map((entry) {
                      final index = entry.key;
                      final step = entry.value;
                      final isFirst = index == 0;
                      final isLast = index == _getOrderTimeline(order!['status']).length - 1;

                      return TimelineTile(
                        isFirst: isFirst,
                        isLast: isLast,
                        alignment: TimelineAlign.manual,
                        lineXY: 0.1,
                        endChild: Padding(
                          padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                step['title'],
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: step['isCompleted']
                                      ? colorScheme.primary
                                      : colorScheme.onSurfaceVariant,
                                ),
                              ),
                            ],
                          ),
                        ),
                        startChild: SizedBox(),
                        indicatorStyle: IndicatorStyle(
                          width: 28,
                          height: 28,
                          indicator: Container(
                            decoration: BoxDecoration(
                              color: step['isCompleted'] ? colorScheme.primary : colorScheme.surfaceVariant,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Icon(
                              step['icon'],
                              size: 16,
                              color: step['isCompleted'] ? colorScheme.onPrimary : colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ),
                        beforeLineStyle: LineStyle(
                          color: colorScheme.primary.withOpacity(0.3),
                          thickness: 2,
                        ),
                        afterLineStyle: LineStyle(
                          color: colorScheme.surfaceVariant,
                          thickness: 2,
                        ),
                      );
                    }).toList(),
                  ),
                ),

                SizedBox(height: 32),

                // Order Items Section
                Text(
                  "Order Items",
                  style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 12),

                // Order items list
                ListView.separated(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: order!['orderItems']?.length ?? 0,
                  separatorBuilder: (context, index) => Divider(height: 1),
                  itemBuilder: (context, index) {
                    var item = order!['orderItems'][index];
                    return Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Row(
                        children: [
                          // Quantity in circle
                          Container(
                            padding: EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: colorScheme.primaryContainer.withOpacity(0.3),
                              shape: BoxShape.circle,
                            ),
                            child: Text(
                              '${item['quantity']}x',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: colorScheme.primary,
                              ),
                            ),
                          ),
                          SizedBox(width: 16),

                          // Item details
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item['menuItem']['name'] ?? "Unnamed item",
                                  style: textTheme.bodyLarge?.copyWith(
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                if (item['menuItem']['description'] != null)
                                  Text(
                                    item['menuItem']['description'],
                                    style: TextStyle(
                                      color: colorScheme.onSurfaceVariant,
                                      fontSize: 13,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                              ],
                            ),
                          ),

                          // Price
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                '\$${(item['quantity'] * item['unitPrice']).toStringAsFixed(2)}',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              Text(
                                '\$${item['unitPrice'].toStringAsFixed(2)} each',
                                style: TextStyle(
                                  color: colorScheme.onSurfaceVariant,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),

                SizedBox(height: 24),
                Divider(thickness: 1),
                SizedBox(height: 16),

                // Order summary section
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Subtotal', style: TextStyle(color: colorScheme.onSurfaceVariant)),
                    Text('\$${order!['totalAmount'].toStringAsFixed(2)}'),
                  ],
                ),
                SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Delivery Fee', style: TextStyle(color: colorScheme.onSurfaceVariant)),
                    Text('\$${order!['deliveryFee'].toStringAsFixed(2)}'),
                  ],
                ),
                SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Tax', style: TextStyle(color: colorScheme.onSurfaceVariant)),
                    Text('\$${order!['tax'].toStringAsFixed(2)}'),
                  ],
                ),
                SizedBox(height: 16),
                Divider(thickness: 1),
                SizedBox(height: 16),

                // Total
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Total',
                      style: textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      '\$${order!['grandTotal'].toStringAsFixed(2)}',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: colorScheme.primary,
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 32),

                // Action buttons
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: Icon(Icons.arrow_back),
                        label: Text("Back to Orders"),
                        style: OutlinedButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 16),
                        ),
                      ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: order!['status'].toString().toLowerCase() == 'cancelled' ||
                            order!['status'].toString().toLowerCase() == 'completed' ||
                            order!['status'].toString().toLowerCase() == 'delivered'
                            ? () {
                          // Reorder functionality
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text("Reorder functionality coming soon")),
                          );
                        }
                            : null,
                        icon: Icon(Icons.replay),
                        label: Text("Reorder"),
                        style: FilledButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 16),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}