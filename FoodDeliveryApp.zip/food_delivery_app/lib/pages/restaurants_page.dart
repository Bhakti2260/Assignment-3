import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:food_delivery_app/core/utils.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:food_delivery_app/pages/restaurant_detail_page.dart';

class RestaurantsPage extends StatefulWidget {
  const RestaurantsPage({Key? key}) : super(key: key);

  @override
  _RestaurantsPageState createState() => _RestaurantsPageState();
}

class _RestaurantsPageState extends State<RestaurantsPage> with SingleTickerProviderStateMixin {
  bool isLoading = false;
  bool isLoadingMore = false;
  String error = '';
  int currentPage = 1;
  final int pageSize = 10;
  int totalCount = 0;
  List<dynamic> restaurants = [];
  List<dynamic> filteredRestaurants = [];
  final TextEditingController _searchController = TextEditingController();
  late final AnimationController _fadeController;
  ScrollController _scrollController = ScrollController();
  String selectedCuisine = 'All';

  // Sample cuisine types - replace with your actual categories from the API
  final List<String> cuisineTypes = [
    'All', 'Italian', 'Chinese', 'Mexican', 'Indian', 'Thai', 'Fast Food', 'Desserts'
  ];

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    fetchRestaurants();

    // Add scroll listener for pagination
    _scrollController.addListener(() {
      if (_scrollController.position.pixels >= _scrollController.position.maxScrollExtent * 0.8 &&
          !isLoadingMore &&
          restaurants.length < totalCount) {
        _loadMoreRestaurants();
      }
    });

    _searchController.addListener(_filterRestaurants);
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _filterRestaurants() {
    if (restaurants.isEmpty) return;

    setState(() {
      final query = _searchController.text.toLowerCase();

      filteredRestaurants = restaurants.where((restaurant) {
        final matchesSearch = restaurant['name'].toString().toLowerCase().contains(query);
        final matchesCuisine = selectedCuisine == 'All' ||
            restaurant['cuisineType']?.toString().toLowerCase() == selectedCuisine.toLowerCase();
        return matchesSearch && matchesCuisine;
      }).toList();
    });
  }

  void _selectCuisine(String cuisine) {
    setState(() {
      selectedCuisine = cuisine;
    });
    _filterRestaurants();
  }

  Future<void> _loadMoreRestaurants() async {
    if (isLoadingMore) return;

    setState(() {
      isLoadingMore = true;
    });

    try {
      await fetchRestaurants(page: currentPage + 1, append: true);
    } finally {
      setState(() {
        isLoadingMore = false;
      });
    }
  }

  Future<void> fetchRestaurants({int page = 1, bool append = false}) async {
    if (!append) {
      setState(() {
        isLoading = true;
        error = '';
      });
    }

    try {
      Dio dio = createDio();
      Response response = await dio.get(
        "/api/restaurants",
        queryParameters: {
          "page": page,
          "pageSize": pageSize,
        },
        options: Options(
          headers: {"Content-Type": "application/json"},
        ),
      );

      if (response.statusCode == 200) {
        var data = response.data;
        final fetchedRestaurants = data['restaurants'] ?? [];

        setState(() {
          currentPage = page;
          totalCount = data['totalCount'] ?? 0;

          if (append) {
            restaurants.addAll(fetchedRestaurants);
          } else {
            restaurants = fetchedRestaurants;
            _fadeController.reset();
            _fadeController.forward();
          }

          // Apply current filters to the new data
          _filterRestaurants();
        });
      } else {
        setState(() {
          error = "Failed to load restaurants. [${response.statusCode}]";
        });
      }
    } on DioException catch (e) {
      setState(() {
        error = "Error loading restaurants: ${e.message}";
      });
    } catch (e) {
      setState(() {
        error = "Error loading restaurants: $e";
      });
    } finally {
      if (!append) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  // Utility function to get distance display
  String _getDistanceText(dynamic restaurant) {
    final distance = restaurant['distance'];
    if (distance == null) return '';

    return distance < 1.0
        ? '${(distance * 1000).toStringAsFixed(0)}m away'
        : '${distance.toStringAsFixed(1)}km away';
  }

  // Star rating widget
  Widget _buildRatingStars(dynamic rating) {
    if (rating == null) return const SizedBox.shrink();

    double ratingValue = 0.0;
    try {
      ratingValue = double.parse(rating.toString());
    } catch (_) {
      return const SizedBox.shrink();
    }

    return Row(
      children: [
        ...List.generate(5, (index) {
          if (index < ratingValue.floor()) {
            return Icon(Icons.star, size: 16, color: Colors.amber[600]);
          } else if (index == ratingValue.floor() && ratingValue % 1 > 0) {
            return Icon(Icons.star_half, size: 16, color: Colors.amber[600]);
          }
          return Icon(Icons.star_border, size: 16, color: Colors.amber[600]);
        }),
        const SizedBox(width: 4),
        Text(
          ratingValue.toStringAsFixed(1),
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        )
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.restaurant_menu,
            size: 80,
            color: Theme.of(context).colorScheme.outline,
          ),
          const SizedBox(height: 16),
          Text(
            "No restaurants found",
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _searchController.text.isNotEmpty || selectedCuisine != 'All'
                ? "Try adjusting your filters"
                : "Check back later for new restaurants",
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 24),
          if (_searchController.text.isNotEmpty || selectedCuisine != 'All')
            FilledButton.icon(
              onPressed: () {
                _searchController.clear();
                setState(() {
                  selectedCuisine = 'All';
                });
                _filterRestaurants();
              },
              icon: const Icon(Icons.refresh),
              label: const Text("Clear filters"),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final filteredList = _searchController.text.isNotEmpty || selectedCuisine != 'All'
        ? filteredRestaurants
        : restaurants;

    return Scaffold(
      body: NestedScrollView(
        headerSliverBuilder: (context, innerBoxIsScrolled) {
          return <Widget>[
            SliverAppBar(
              title: Text("Restaurants", style: TextStyle(fontWeight: FontWeight.bold)),
              pinned: true,
              floating: true,
              forceElevated: innerBoxIsScrolled,
              actions: [
                IconButton(
                  onPressed: () => fetchRestaurants(),
                  icon: Icon(Icons.refresh),
                  tooltip: "Refresh",
                ),
              ],
              bottom: PreferredSize(
                preferredSize: Size.fromHeight(56),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      hintText: "Search restaurants...",
                      prefixIcon: Icon(Icons.search),
                      suffixIcon: _searchController.text.isNotEmpty
                          ? IconButton(
                        icon: Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                        },
                      )
                          : null,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: colorScheme.surfaceVariant.withOpacity(0.5),
                      contentPadding: EdgeInsets.symmetric(vertical: 8),
                    ),
                  ),
                ),
              ),
            ),
          ];
        },
        body: Column(
          children: [
            // Cuisine filters
            Container(
              height: 60,
              padding: EdgeInsets.symmetric(vertical: 8),
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: cuisineTypes.length,
                padding: EdgeInsets.symmetric(horizontal: 8),
                itemBuilder: (context, index) {
                  final cuisine = cuisineTypes[index];
                  final selected = selectedCuisine == cuisine;

                  return Padding(
                    padding: EdgeInsets.symmetric(horizontal: 4),
                    child: FilterChip(
                      label: Text(cuisine),
                      selected: selected,
                      onSelected: (_) => _selectCuisine(cuisine),
                      showCheckmark: false,
                      avatar: selected ? Icon(
                        index == 0 ? Icons.restaurant : Icons.lunch_dining,
                        size: 16,
                        color: selected ? colorScheme.onSecondaryContainer : colorScheme.onSurfaceVariant,
                      ) : null,
                    ),
                  );
                },
              ),
            ),

            // Main content
            Expanded(
              child: isLoading
                  ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(color: colorScheme.primary),
                    SizedBox(height: 16),
                    Text(
                      'Loading restaurants...',
                      style: TextStyle(color: colorScheme.onSurfaceVariant),
                    ),
                  ],
                ),
              )
                  : error.isNotEmpty
                  ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                          Icons.error_outline,
                          size: 60,
                          color: colorScheme.error
                      ),
                      SizedBox(height: 16),
                      Text(
                        error,
                        style: TextStyle(color: colorScheme.error),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 24),
                      FilledButton.icon(
                        onPressed: () => fetchRestaurants(),
                        icon: Icon(Icons.refresh),
                        label: Text("Try Again"),
                      ),
                    ],
                  ),
                ),
              )
                  : filteredList.isEmpty
                  ? _buildEmptyState()
                  : RefreshIndicator(
                onRefresh: () => fetchRestaurants(),
                child: FadeTransition(
                  opacity: _fadeController,
                  child: AnimationLimiter(
                    child: ListView.builder(
                      controller: _scrollController,
                      padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                      itemCount: filteredList.length + (isLoadingMore ? 1 : 0),
                      itemBuilder: (context, index) {
                        if (index == filteredList.length) {
                          return Center(
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                              ),
                            ),
                          );
                        }

                        return AnimationConfiguration.staggeredList(
                          position: index,
                          duration: const Duration(milliseconds: 375),
                          child: SlideAnimation(
                            verticalOffset: 50.0,
                            child: FadeInAnimation(
                              child: _buildRestaurantCard(context, filteredList[index], colorScheme),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRestaurantCard(BuildContext context, dynamic restaurant, ColorScheme colorScheme) {
    final imageUrl = "${getBaseUrl()}${restaurant['imageUrl'] ?? ''}";
    final cuisineType = restaurant['title'] ?? '';
    final openingHours = restaurant['openingHours'] ?? 'Unknown hours';
    final priceRange = restaurant['priceRange'] ?? '';
    final distance = _getDistanceText(restaurant);

    // Determine if restaurant is open
    bool isOpen = restaurant['isOpen'] ?? true;  // Default to open if not specified

    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => RestaurantDetailsPage(
                restaurantId: restaurant['id'],
              ),
            ),
          );
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Restaurant image
            Stack(
              children: [
                AspectRatio(
                  aspectRatio: 16 / 9,
                  child: CachedNetworkImage(
                    imageUrl: imageUrl,
                    fit: BoxFit.cover,
                    placeholder: (context, url) => Container(
                      color: Colors.grey[300],
                      child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
                    ),
                    errorWidget: (context, url, error) => Container(
                      color: Colors.grey[300],
                      child: Icon(Icons.restaurant, size: 40, color: Colors.grey[500]),
                    ),
                  ),
                ),

                // Open/Closed indicator
                Positioned(
                  top: 12,
                  right: 12,
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: isOpen
                          ? colorScheme.primaryContainer
                          : colorScheme.errorContainer,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(
                      isOpen ? 'Open' : 'Closed',
                      style: TextStyle(
                        color: isOpen
                            ? colorScheme.onPrimaryContainer
                            : colorScheme.onErrorContainer,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              ],
            ),

            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Restaurant name and rating
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(
                          restaurant['name'] ?? "Restaurant",
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      _buildRatingStars(restaurant['rating']),
                    ],
                  ),

                  const SizedBox(height: 8),

                  // Cuisine type and price range
                  Row(
                    children: [
                      Icon(
                        Icons.restaurant,
                        size: 14,
                        color: colorScheme.primary,
                      ),
                      SizedBox(width: 4),
                      Text(
                        cuisineType,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: colorScheme.onSurfaceVariant,
                        ),
                      ),
                      if (priceRange.isNotEmpty) ...[
                        Text(
                          ' • ',
                          style: TextStyle(color: colorScheme.onSurfaceVariant),
                        ),
                        Text(
                          priceRange,
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ],
                  ),

                  const SizedBox(height: 4),

                  // Hours and distance
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Row(
                          children: [
                            Icon(
                              Icons.access_time,
                              size: 14,
                              color: colorScheme.primary,
                            ),
                            SizedBox(width: 4),
                            Flexible(
                              child: Text(
                                openingHours,
                                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  color: colorScheme.onSurfaceVariant,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (distance.isNotEmpty)
                        Row(
                          children: [
                            Icon(
                              Icons.place,
                              size: 14,
                              color: colorScheme.primary,
                            ),
                            SizedBox(width: 4),
                            Text(
                              distance,
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: colorScheme.onSurfaceVariant,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}