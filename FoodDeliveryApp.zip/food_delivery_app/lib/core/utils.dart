import 'dart:io';

import 'package:dio/dio.dart';
import 'package:dio/io.dart';

String getBaseUrl() {
  if (Platform.isAndroid) {
    return 'https://10.0.2.2:7010'; // Android emulator
  } else if (Platform.isIOS) {
    return 'https://localhost:7010'; // iOS simulator
  } else {
    return 'https://localhost:7010'; // Real devices (Use your actual local IP)
  }
}


Dio createDio() {
  final dio = Dio();
  dio.options.baseUrl = getBaseUrl();

  // Disable certificate verification (only for development)
  (dio.httpClientAdapter as IOHttpClientAdapter).createHttpClient = () {
    final client = HttpClient()
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
    return client;
  };

  return dio;
}