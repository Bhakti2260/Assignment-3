import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:food_delivery_app/core/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OrderApiService {
  final Dio _dio;

  OrderApiService({Dio? dio}) : _dio = dio ?? createDio();

  /// Retrieves the stored JWT token from SharedPreferences.
  Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  /// Helper to set authorization header.
  Future<Options> _getAuthOptions() async {
    final token = await _getToken();
    return Options(
      headers: {
        "Content-Type": "application/json",
        if (token != null) "Authorization": "Bearer $token",
      },
    );
  }

  /// Creates a new order.
  ///
  /// [orderRequest] should be a Map containing keys:
  /// - "CustomerId": String,
  /// - "RestaurantId": String,
  /// - "OrderItems": List<Map<String, dynamic>> (each with "MenuItemId" and "Quantity").
  Future<Map<String, dynamic>> createOrder(Map<String, dynamic> orderRequest) async {
    try {
      final options = await _getAuthOptions();
      Response response = await _dio.post(
        "/api/order",
        data: jsonEncode(orderRequest),
        options: options,
      );
      if (response.statusCode == 200) {
        return response.data as Map<String, dynamic>;
      } else {
        throw Exception("Failed to create order. [${response.statusCode}]");
      }
    } on DioException catch (e) {
      print(e.stackTrace);
      throw Exception("Error creating order: ${e.message}");
    }
  }

  /// Retrieves an order by its [orderId].
  Future<Map<String, dynamic>> getOrder(int orderId) async {
    try {
      final options = await _getAuthOptions();
      Response response = await _dio.get(
        "/api/order/$orderId",
        options: options,
      );
      if (response.statusCode == 200) {
        return response.data as Map<String, dynamic>;
      } else {
        throw Exception("Failed to fetch order. [${response.statusCode}]");
      }
    } on DioException catch (e) {
      throw Exception("Error fetching order: ${e.message}");
    }
  }

  /// Cancels an order if it is cancellable.
  Future<Map<String, dynamic>> cancelOrder(int orderId) async {
    try {
      final options = await _getAuthOptions();
      // Using PUT for cancellation (as defined in your API)
      Response response = await _dio.put(
        "/api/order/cancel/$orderId",
        options: options,
      );
      if (response.statusCode == 200) {
        return response.data as Map<String, dynamic>;
      } else {
        throw Exception("Failed to cancel order. [${response.statusCode}]");
      }
    } on DioException catch (e) {
      throw Exception("Error cancelling order: ${e.message}");
    }
  }

  /// Retrieves all orders for a given customer.
  Future<List<dynamic>> getOrdersByCustomer(String customerId) async {
    try {
      final options = await _getAuthOptions();
      Response response = await _dio.get(
        "/api/order/customer/$customerId",
        options: options,
      );
      if (response.statusCode == 200) {
        return response.data as List<dynamic>;
      } else {
        throw Exception("Failed to fetch orders. [${response.statusCode}]");
      }
    } on DioException catch (e) {
      print(e.stackTrace);
      throw Exception("Error fetching orders: ${e.message}");
    }
  }
}
