import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:food_delivery_app/core/utils.dart';

class MenuApiService {
  final Dio _dio;

  MenuApiService({Dio? dio}) : _dio = dio ?? createDio();

  /// Fetches a paginated list of menu items for a specific restaurant.
  /// [restaurantId] is the identifier for the restaurant.
  /// Optional [page] and [pageSize] control pagination.
  Future<List<dynamic>> getMenuByRestaurant(
      String restaurantId, {int page = 1, int pageSize = 10}) async {
    try {
      final response = await _dio.get(
        "/api/menu/byrestaurant/$restaurantId",
        queryParameters: {
          "page": page,
          "pageSize": pageSize,
        },
        options: Options(
          headers: {"Content-Type": "application/json"},
        ),
      );
      // Expecting a response with keys: totalCount, page, pageSize, restaurants
      return response.data;
    } on DioException catch (e) {
      throw Exception("Error fetching menu by restaurant: ${e.message}");
    }
  }

  /// Fetches 10 featured menu items from restaurants in the given city.
  /// [city] is the city filter applied on the restaurant.
  Future<List<dynamic>> getFeaturedMenus(String city) async {
    try {
      final response = await _dio.get(
        "/api/menu/featured",
        queryParameters: {"city": city},
        options: Options(
          headers: {"Content-Type": "application/json"},
        ),
      );
      // Assuming API returns an object with a 'restaurants' array.
      return response.data as List<dynamic>;
    } on DioException catch (e) {
      throw Exception("Error fetching featured menus: ${e.message}");
    }
  }

  /// Fetches all menu items for restaurants in a specified city.
  /// [city] is used to filter restaurants.
  Future<List<dynamic>> getMenuByCity(String city) async {
    try {
      final response = await _dio.get(
        "/api/menu/bycity",
        queryParameters: {"city": city},
        options: Options(
          headers: {"Content-Type": "application/json"},
        ),
      );
      // Here we assume the API returns a list of menu items.
      return response.data as List<dynamic>;
    } on DioException catch (e) {
      throw Exception("Error fetching menus by city: ${e.message}");
    }
  }
}
