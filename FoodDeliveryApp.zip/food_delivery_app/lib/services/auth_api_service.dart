import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:food_delivery_app/core/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthApiService {
  final Dio _dio = createDio();

  Future<Map<String, dynamic>> login(String email, String password) async {
    try {
      Response response = await _dio.post(
        "/api/auth/login",
        data: jsonEncode({
          "email": email,
          "password": password,
        }),
        options: Options(
          headers: {"Content-Type": "application/json"},
        ),
      );

      if (response.statusCode == 200) {
        final token = response.data['token'];
        final user = response.data['user'];

        // Store user data in shared preferences
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('user', jsonEncode(user));
        await prefs.setString('token', token);

        return {'success': true, 'user': user};
      } else {
        return {'success': false, 'message': "Login failed: ${response.data}"};
      }
    } on DioException catch (e) {
      String errorMessage = "An error occurred";
      if (e.response?.data != null) {
        if (e.response?.data is Map<String, dynamic>) {
          errorMessage = e.response?.data['message'] ?? "An error occurred";
        } else {
          errorMessage = "An error occurred: ${e.response?.data}";
        }
      } else {
        errorMessage = "Network error: ${e.message}";
      }

      return {'success': false, 'message': errorMessage};
    } catch (e) {
      return {'success': false, 'message': "An error occurred: $e"};
    }
  }

  Future<Map<String, dynamic>> register(String name, String email, String password, String confirmPassword) async {
    try {
      Response response = await _dio.post(
        "/api/auth/register",
        data: jsonEncode({
          "name": name,
          "email": email,
          "password": password,
          "confirmPassword": confirmPassword,
        }),
        options: Options(
          headers: {"Content-Type": "application/json"},
        ),
      );

      if (response.statusCode == 200) {
        return {'success': true, 'message': 'Account created successfully'};
      } else {
        return {'success': false, 'message': "Sign up failed: ${response.data}"};
      }
    } on DioException catch (e) {
      String errorMessage = "Registration failed";

      if (e.response?.data is List) {
        List<dynamic> errors = e.response?.data;
        if (errors.isNotEmpty) {
          errorMessage = errors[0]['description'] ?? errorMessage;
        }
      } else if (e.response?.data is Map) {
        errorMessage = e.response?.data['message'] ?? errorMessage;
      } else {
        errorMessage = "Connection error: ${e.message}";
      }

      return {'success': false, 'message': errorMessage};
    } catch (e) {
      return {'success': false, 'message': "An error occurred: $e"};
    }
  }
}