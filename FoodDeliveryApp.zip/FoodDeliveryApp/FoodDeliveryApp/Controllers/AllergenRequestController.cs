﻿using FoodDeliveryApp.Database;
using FoodDeliveryApp.Entities;
using FoodDeliveryApp.Enums;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace FoodDeliveryApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AllergenRequestController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public AllergenRequestController(ApplicationDbContext context)
        {
            _context = context;
        }

        public class AllergenRequestModel
        {
            [Required]
            public string Name { get; set; }
            public string Description { get; set; }
        }


        /**
         *  @api {post} /api/AllergenRequest Request New Allergen
         * 
         *  POST request to /api/AllergenRequest
         *  {
         *      "name": "Peanuts",
         *      "description": "A common allergen found in many foods."
         *  }
         */
        [HttpPost]
        public async Task<IActionResult> RequestNewAllergen([FromBody] AllergenRequestModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var allergen = new Allergen
            {
                Name = model.Name,
                Description = model.Description,
                Status = AllergenStatus.Pending
            };

            _context.Allergens.Add(allergen);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Allergen request submitted successfully." });
        }
    }
}
