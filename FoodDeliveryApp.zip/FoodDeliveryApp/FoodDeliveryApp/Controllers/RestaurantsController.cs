﻿using FoodDeliveryApp.Database;
using FoodDeliveryApp.Entities;
using FoodDeliveryApp.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FoodDeliveryApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RestaurantsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public RestaurantsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/Restaurants
        // Optional query parameters:
        //   search: search term for restaurant name
        //   status: filter by RestaurantStatus (e.g. Approved)
        //   page: page number (default 1)
        //   pageSize: number of items per page (default 10)
        [HttpGet]
        public async Task<IActionResult> GetRestaurants(
            [FromQuery] string? search,
            [FromQuery] RestaurantStatus? status,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 10)
        {
            // Since Restaurant is a subclass of ApplicationUser using TPH,
            // we can query only Restaurant entities via OfType<Restaurant>()
            var query = _context.Users
                                .OfType<Restaurant>()
                                .AsQueryable();

            // Apply search filter (by Name)
            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(r => r.Name.Contains(search));
            }

            // Apply status filter
            if (status.HasValue)
            {
                query = query.Where(r => r.Status == status.Value);
            }

            // Get total count for pagination metadata
            int totalCount = await query.CountAsync();

            // Retrieve the paginated list (ordering by Name)
            var restaurants = await query
                                    .OrderBy(r => r.Name)
                                    .Skip((page - 1) * pageSize)
                                    .Take(pageSize)
                                    .Select(r => new
                                    {
                                        r.Id,
                                        r.Name,
                                        r.Email,
                                        r.Description,
                                        r.ImageUrl,
                                        r.Title,
                                        r.Status,
                                        r.Rating,
                                        r.RatingCount
                                    })
                                    .ToListAsync();

            // Return JSON with pagination metadata
            return Ok(new
            {
                totalCount,
                page,
                pageSize,
                restaurants
            });
        }

        // GET: api/Restaurants/{id}
        // Retrieve a single restaurant by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetRestaurant(string id)
        {
            var restaurant = await _context.Users
                .OfType<Restaurant>()
                .Select(r => new
                {
                    r.Id,
                    r.Name,
                    r.Email,
                    r.Description,
                    r.ImageUrl,
                    r.Title,
                    r.Status,
                    r.Rating,
                    r.RatingCount
                })
                .FirstOrDefaultAsync(r => r.Id == id);
            if (restaurant == null)
            {
                return NotFound(new { message = "Restaurant not found." });
            }
            return Ok(restaurant);
        }
    }
}
