﻿using FoodDeliveryApp.Database;
using FoodDeliveryApp.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FoodDeliveryApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MenuController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public MenuController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/menu
        [HttpGet]
        public async Task<IActionResult> GetMenuItems()
        {
            var items = await _context.MenuItems
                .Include(mi => mi.Restaurant)
                .Include(mi => mi.Allergens)
                .Where(mi => !mi.IsDeleted)
                .Select(mi => new
                {
                    mi.Id,
                    mi.Name,
                    mi.Description,
                    mi.Price,
                    mi.IsPetFriendly,
                    mi.ImageUrl,
                    Restaurant = new
                    {
                        mi.Restaurant.Id,
                        mi.Restaurant.Name
                    },
                    Allergens = mi.Allergens.Select(a => new
                    {
                        a.Id,
                        a.Name,
                        a.Description,
                        a.Status
                    }).ToList()
                })
                .ToListAsync();

            return Ok(items);
        }


        // GET: api/menu/byrestaurant/{restaurantId}
        // Returns all menu items for a specific restaurant.
        [HttpGet("byrestaurant/{restaurantId}")]
        public async Task<IActionResult> GetMenuByRestaurant(string restaurantId)
        {
            var menuItems = await _context.MenuItems
                .Include(mi => mi.Restaurant)
                .Where(mi => mi.RestaurantId == restaurantId && !mi.IsDeleted)
                .Select(mi => new {
                    mi.Id,
                    mi.Name,
                    mi.Description,
                    mi.Price,
                    mi.IsPetFriendly,
                    mi.ImageUrl,
                    Restaurant = new
                    {
                        mi.Restaurant.Id,
                        mi.Restaurant.Name,
                        mi.Restaurant.City,
                        mi.Restaurant.Status
                    }
                })
                .ToListAsync();

            return Ok(menuItems);
        }

        // GET: api/menu/featured?city=CityName
        // Returns 10 featured menu items from restaurants in the specified city.
        // Here, we order by restaurant rating (descending).
        [HttpGet("featured")]
        public async Task<IActionResult> GetFeaturedMenus([FromQuery] string city)
        {
            if (string.IsNullOrWhiteSpace(city))
            {
                return BadRequest(new { status = 400, error = "BadRequest", message = "City parameter is required" });
            }

            var featuredMenus = await _context.MenuItems
                .Include(mi => mi.Restaurant)
                .Where(mi => !mi.IsDeleted && mi.Restaurant.City == city)
                .OrderByDescending(mi => mi.Restaurant.Rating)
                .Take(10)
                .Select(mi => new {
                    mi.Id,
                    mi.Name,
                    mi.Description,
                    mi.Price,
                    mi.IsPetFriendly,
                    mi.ImageUrl,
                    Restaurant = new
                    {
                        mi.Restaurant.Id,
                        mi.Restaurant.Name,
                        mi.Restaurant.City,
                        mi.Restaurant.Rating
                    }
                })
                .ToListAsync();

            return Ok(featuredMenus);
        }

        // GET: api/menu/bycity?city=CityName
        // Returns all menu items for restaurants in the given city.
        [HttpGet("bycity")]
        public async Task<IActionResult> GetMenuByCity([FromQuery] string city)
        {
            if (string.IsNullOrWhiteSpace(city))
            {
                return BadRequest(new { status = 400, error = "BadRequest", message = "City parameter is required" });
            }

            var menuItems = await _context.MenuItems
                .Include(mi => mi.Restaurant)
                .Where(mi => !mi.IsDeleted && mi.Restaurant.City == city)
                .Select(mi => new {
                    mi.Id,
                    mi.Name,
                    mi.Description,
                    mi.Price,
                    mi.IsPetFriendly,
                    mi.ImageUrl,
                    Restaurant = new
                    {
                        mi.Restaurant.Id,
                        mi.Restaurant.Name,
                        mi.Restaurant.City
                    }
                })
                .ToListAsync();

            return Ok(menuItems);
        }

    }
}
