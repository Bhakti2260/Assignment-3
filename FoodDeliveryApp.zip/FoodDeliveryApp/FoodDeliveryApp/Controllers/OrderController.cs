﻿using FoodDeliveryApp.Database;
using FoodDeliveryApp.Entities;
using FoodDeliveryApp.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace FoodDeliveryApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public OrderController(ApplicationDbContext context)
        {
            _context = context;
        }

        // POST: api/order
        // Create a new order. For each OrderItem, copy the current MenuItem price into UnitPrice.
        [HttpPost]
        public async Task<IActionResult> CreateOrder([FromBody] CreateOrderRequest request)
        {
            if (request == null || request.OrderItems == null || !request.OrderItems.Any())
            {
                return BadRequest(new { message = "Order must contain at least one item." });
            }

            var order = new Order
            {
                CustomerId = request.CustomerId,
                RestaurantId = request.RestaurantId,
                OrderDate = DateTime.UtcNow,
                Status = OrderStatus.Pending,
            };

            foreach (var item in request.OrderItems)
            {
                var menuItem = await _context.MenuItems.FirstOrDefaultAsync(mi => mi.Id == item.MenuItemId);
                if (menuItem == null)
                {
                    return BadRequest(new { message = $"Menu item with id {item.MenuItemId} not found." });
                }
                var orderItem = new OrderItem
                {
                    MenuItemId = item.MenuItemId,
                    Quantity = item.Quantity,
                    UnitPrice = menuItem.Price  // capture current price
                };
                order.OrderItems.Add(orderItem);
            }

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();
            return Ok(order);
        }

        // GET: api/order/{id}
        // Retrieve order details (including items and their unit prices).
        [HttpGet("{id}")]
        public async Task<IActionResult> GetOrder(int id)
        {
            var order = await _context.Orders
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.MenuItem)
                .FirstOrDefaultAsync(o => o.Id == id);

            if (order == null)
                return NotFound(new { message = "Order not found." });

            // Create object of order and add totalAmount, tax, deliveryFee, and grandTotal
            var orderDetails = new
            {
                order.Id,
                order.CustomerId,
                order.RestaurantId,
                order.OrderDate,
                Status = order.Status.ToString(),
                OrderItems = order.OrderItems.Select(oi => new
                {
                    oi.Id,
                    oi.MenuItemId,
                    oi.Quantity,
                    oi.UnitPrice,
                    MenuItem = new
                    {
                        oi.MenuItem.Id,
                        oi.MenuItem.Name,
                        oi.MenuItem.Description,
                        oi.MenuItem.Price,
                        oi.MenuItem.IsPetFriendly,
                        oi.MenuItem.ImageUrl
                    }
                }).ToList(),
                TotalAmount = order.OrderItems.Sum(oi => oi.Quantity * oi.UnitPrice),
                Tax = 0.05m * order.OrderItems.Sum(oi => oi.Quantity * oi.UnitPrice),
                DeliveryFee = 5.00,
                GrandTotal = order.OrderItems.Sum(oi => oi.Quantity * oi.UnitPrice) + 0.05m * order.OrderItems.Sum(oi => oi.Quantity * oi.UnitPrice) + 5.00m
            };

            return Ok(orderDetails);
        }

        // PUT: api/order/cancel/{id}
        // Cancel an order if it is still in a cancellable state (e.g. Pending or Accepted).
        [HttpPut("cancel/{id}")]
        public async Task<IActionResult> CancelOrder(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
                return NotFound(new { message = "Order not found." });

            if (order.Status != OrderStatus.Pending && order.Status != OrderStatus.Accepted)
            {
                return BadRequest(new { message = "Order cannot be cancelled at this stage." });
            }

            order.Status = OrderStatus.Cancelled;
            _context.Orders.Update(order);
            await _context.SaveChangesAsync();
            return Ok(new { message = "Order cancelled successfully." });
        }

        // GET: api/order/customer/{customerId}
        // Optionally, retrieve all orders for a given customer.
        [HttpGet("customer/{customerId}")]
        public async Task<IActionResult> GetOrdersByCustomer(string customerId)
        {
            var orders = await _context.Orders
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.MenuItem)
                .Include(o => o.Restaurant)
                .Where(o => o.CustomerId == customerId)
                .Select(o => new
                {
                    o.Id,
                    o.CustomerId,
                    o.RestaurantId,
                    o.OrderDate,
                    Status = o.Status.ToString(),
                    OrderItems = o.OrderItems.Select(oi => new
                    {
                        oi.Id,
                        oi.MenuItemId,
                        oi.Quantity,
                        oi.UnitPrice,
                        MenuItem = new
                        {
                            oi.MenuItem.Id,
                            oi.MenuItem.Name,
                            oi.MenuItem.Description,
                            oi.MenuItem.Price,
                            oi.MenuItem.IsPetFriendly,
                            oi.MenuItem.ImageUrl
                        }
                    }).ToList(),
                    Restaurant = new
                    {
                        o.Restaurant.Id,
                        o.Restaurant.Name,
                        o.Restaurant.City,
                        o.Restaurant.Status
                    },
                    TotalAmount = o.OrderItems.Sum(oi => oi.Quantity * oi.UnitPrice),
                    Tax = 0.05m * o.OrderItems.Sum(oi => oi.Quantity * oi.UnitPrice),
                    DeliveryFee = 5.00,
                    GrandTotal = o.OrderItems.Sum(oi => oi.Quantity * oi.UnitPrice) + 0.05m * o.OrderItems.Sum(oi => oi.Quantity * oi.UnitPrice) + 5.00m
                })
                .ToListAsync();


            return Ok(orders);
        }
    }

    public class CreateOrderRequest
    {
        public string CustomerId { get; set; }
        public string RestaurantId { get; set; }
        public List<CreateOrderItemRequest> OrderItems { get; set; }
    }

    public class CreateOrderItemRequest
    {
        public int MenuItemId { get; set; }
        public int Quantity { get; set; }
    }
}
