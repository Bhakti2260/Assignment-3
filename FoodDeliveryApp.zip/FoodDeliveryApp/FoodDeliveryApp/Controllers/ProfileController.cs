﻿using FoodDeliveryApp.Database;
using FoodDeliveryApp.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FoodDeliveryApp.Controllers
{
    [ApiController]
    [Route("api/user/profile")]
    [Authorize(AuthenticationSchemes = "JwtBearer")]
    public class ProfileController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> _userManager;

        public ProfileController(UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
        }

        // GET: api/user/profile
        [HttpGet]
        public async Task<IActionResult> GetProfile()
        {
            var userId = _userManager.GetUserId(User);
            if (userId == null)
                return Unauthorized();

            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
                return NotFound();

            // Build a simple profile response.
            var profile = new ProfileResponse
            {
                Name = user.Name,
                Email = user.Email,
                Phone = user.PhoneNumber,    // IdentityUser provides PhoneNumber
                Address = user.Address,      // Assuming ApplicationUser has Address property
                Role = (await _userManager.GetRolesAsync(user)).FirstOrDefault() ?? ""
            };

            return Ok(profile);
        }

        // PUT: api/user/profile
        [HttpPut]
        public async Task<IActionResult> UpdateProfile([FromBody] ProfileUpdateModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var userId = _userManager.GetUserId(User);
            if (userId == null)
                return Unauthorized();

            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
                return NotFound();

            user.Name = model.Name;
            user.PhoneNumber = model.Phone;
            user.Address = model.Address;

            var result = await _userManager.UpdateAsync(user);
            if (!result.Succeeded)
            {
                return BadRequest(new
                {
                    status = 400,
                    error = "UpdateError",
                    message = string.Join("; ", result.Errors.Select(e => e.Description))
                });
            }

            return Ok(new { status = 200, message = "Profile updated successfully" });
        }
    }

    public class ProfileResponse
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string Role { get; set; }
    }

    public class ProfileUpdateModel
    {
        [Required]
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
    }
}
