﻿namespace FoodDeliveryApp.Enums
{
    public enum RestaurantStatus
    {
        Pending,
        Approved,
        Rejected,
        Blocked
    }
}
