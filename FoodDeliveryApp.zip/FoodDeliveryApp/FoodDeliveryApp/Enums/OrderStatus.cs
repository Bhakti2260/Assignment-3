﻿namespace FoodDeliveryApp.Enums
{
    public enum OrderStatus
    {
        Pending,       // Order just placed
        Accepted,      // Restaurant accepted but not yet in production
        InPreparation, // Items are being made
        Ready,         // Order is ready for pickup/delivery
        Delivered,     // Order delivered to customer
        Cancelled      // Order cancelled by customer
    }
}
