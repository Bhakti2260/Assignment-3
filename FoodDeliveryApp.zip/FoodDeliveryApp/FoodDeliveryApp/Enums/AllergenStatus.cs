﻿namespace FoodDeliveryApp.Enums
{
    public enum AllergenStatus
    {
        Pending,
        Approved,
        Rejected
    }
}
