using FoodDeliveryApp.Database;
using FoodDeliveryApp.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using FoodDeliveryApp.Enums;

namespace FoodDeliveryApp.Pages.Restaurant.Menu
{
    [Authorize(Roles = "Restaurant")]
    public class AddMenuItemModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IWebHostEnvironment _environment;

        public AddMenuItemModel(ApplicationDbContext context,
                                UserManager<ApplicationUser> userManager,
                                IWebHostEnvironment environment)
        {
            _context = context;
            _userManager = userManager;
            _environment = environment;
        }

        [BindProperty]
        public InputModel Input { get; set; }

        public List<SelectListItem> AllergenOptions { get; set; } = new List<SelectListItem>();

        public class InputModel
        {
            [Required(ErrorMessage = "Name is required.")]
            public string Name { get; set; }

            public string Description { get; set; }

            [Required(ErrorMessage = "Price is required.")]
            [Range(0, double.MaxValue, ErrorMessage = "Price must be non-negative.")]
            public decimal Price { get; set; }

            public bool IsPetFriendly { get; set; }

            public IFormFile? ImageFile { get; set; }

            public string? ImageUrl { get; set; }

            public List<int> SelectedAllergenIds { get; set; } = new List<int>();

        }

        public void OnGet()
        {
            var allergens = _context.Allergens.Where(a => a.Status == AllergenStatus.Approved).ToList();
            AllergenOptions = allergens.Select(a => new SelectListItem
            {
                Value = a.Id.ToString(),
                Text = a.Name
            }).ToList();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var menuItem = new MenuItem
            {
                RestaurantId = user.Id,
                Name = Input.Name,
                Description = Input.Description,
                Price = Input.Price,
                IsPetFriendly = Input.IsPetFriendly
            };

            if (Input.ImageFile != null)
            {
                var folderPath = Path.Combine(_environment.WebRootPath, "images", "menu");
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                var fileName = Guid.NewGuid().ToString() + Path.GetExtension(Input.ImageFile.FileName);
                var filePath = Path.Combine(folderPath, fileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await Input.ImageFile.CopyToAsync(stream);
                }
                menuItem.ImageUrl = $"/images/menu/{fileName}";
            }
            else
            {
                menuItem.ImageUrl = null;
            }

            menuItem.Allergens.Clear();
            if (Input.SelectedAllergenIds.Any())
            {
                var selectedAllergens = _context.Allergens.Where(a => Input.SelectedAllergenIds.Contains(a.Id)).ToList();
                foreach (var allergen in selectedAllergens)
                {
                    menuItem.Allergens.Add(allergen);
                }
            }

            _context.MenuItems.Add(menuItem);
            await _context.SaveChangesAsync();
            return RedirectToPage("Index");
        }
    }
}
