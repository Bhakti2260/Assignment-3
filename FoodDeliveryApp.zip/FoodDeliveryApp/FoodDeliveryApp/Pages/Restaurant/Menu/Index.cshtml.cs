using FoodDeliveryApp.Database;
using FoodDeliveryApp.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodDeliveryApp.Pages.Restaurant.Menu
{
    [Authorize(Roles = "Restaurant")]
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public IndexModel(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IList<MenuItem> MenuItems { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            // Retrieve only menu items that belong to the current restaurant user and are not soft-deleted
            MenuItems = _context.MenuItems
                                .Where(m => m.RestaurantId == user.Id && !m.IsDeleted)
                                .ToList();
            return Page();
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            var menuItem = await _context.MenuItems.FindAsync(id);
            if (menuItem == null || menuItem.RestaurantId != user.Id)
            {
                return Forbid();
            }
            // Soft delete: mark as deleted instead of removing from the database
            menuItem.IsDeleted = true;
            _context.MenuItems.Update(menuItem);
            await _context.SaveChangesAsync();
            return RedirectToPage();
        }
    }
}
