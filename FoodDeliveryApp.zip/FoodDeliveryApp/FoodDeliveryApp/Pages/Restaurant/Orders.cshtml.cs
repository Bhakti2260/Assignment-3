using FoodDeliveryApp.Database;
using FoodDeliveryApp.Entities;
using FoodDeliveryApp.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace FoodDeliveryApp.Pages.Restaurant
{
    [Authorize(Roles = "Restaurant")]
    public class OrdersModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ILogger<OrdersModel> _logger;

        public OrdersModel(ApplicationDbContext context, UserManager<ApplicationUser> userManager, ILogger<OrdersModel> logger)
        {
            _context = context;
            _userManager = userManager;
            _logger = logger;
        }

        public List<Order> Orders { get; set; } = new List<Order>();
        public string? ErrorMessage { get; set; }
        public string? SuccessMessage { get; set; }

        [BindProperty]
        public int OrdersCount { get; set; }

        [BindProperty]
        public decimal TodayRevenue { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Challenge();
            }

            Orders = await _context.Orders
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.MenuItem)
                .Include(o => o.Customer)
                .Where(o => o.RestaurantId == user.Id)
                .OrderByDescending(o => o.OrderDate)
                .ToListAsync();

            // Calculate today's revenue from completed orders
            TodayRevenue = Orders
                .Where(o => o.Status == OrderStatus.Delivered && o.OrderDate.Date == DateTime.Today)
                .Sum(o => o.OrderItems.Sum(oi => oi.Quantity * oi.MenuItem.Price));

            OrdersCount = Orders.Count;

            return Page();
        }

        public async Task<IActionResult> OnPostAcceptAsync(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Challenge();
            }

            var order = await _context.Orders.FindAsync(id);
            if (order == null || order.RestaurantId != user.Id)
            {
                return NotFound();
            }

            if (order.Status != OrderStatus.Pending)
            {
                ErrorMessage = "Only pending orders can be accepted.";
                return await OnGetAsync();
            }

            order.Status = OrderStatus.Accepted;

            _context.Orders.Update(order);
            await _context.SaveChangesAsync();

            SuccessMessage = "Order has been accepted and moved to preparation.";
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostReadyForDeliveryAsync(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Challenge();
            }

            var order = await _context.Orders.FindAsync(id);
            if (order == null || order.RestaurantId != user.Id)
            {
                return NotFound();
            }

            if (order.Status != OrderStatus.Accepted)
            {
                ErrorMessage = "Only orders in preparation can be marked as ready for delivery.";
                return await OnGetAsync();
            }

            order.Status = OrderStatus.Ready;

            _context.Orders.Update(order);
            await _context.SaveChangesAsync();

            SuccessMessage = "Order has been marked as ready for delivery.";
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostMarkDeliveredAsync(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Challenge();
            }

            var order = await _context.Orders.FindAsync(id);
            if (order == null || order.RestaurantId != user.Id)
            {
                return NotFound();
            }

            if (order.Status != OrderStatus.Ready)
            {
                ErrorMessage = "Only orders marked as ready can be completed as delivered.";
                return await OnGetAsync();
            }

            order.Status = OrderStatus.Delivered;

            _context.Orders.Update(order);
            await _context.SaveChangesAsync();

            SuccessMessage = "Order has been marked as delivered.";
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostCancelAsync(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Challenge();
            }

            var order = await _context.Orders.FindAsync(id);
            if (order == null || order.RestaurantId != user.Id)
            {
                return NotFound();
            }

            if (order.Status != OrderStatus.Pending && order.Status != OrderStatus.Accepted)
            {
                ErrorMessage = "Order cannot be cancelled at this stage.";
                return await OnGetAsync();
            }

            order.Status = OrderStatus.Cancelled;

            _context.Orders.Update(order);
            await _context.SaveChangesAsync();

            SuccessMessage = "Order has been cancelled.";
            return RedirectToPage();
        }

        // Handler for getting order timeline data via AJAX
        public async Task<IActionResult> OnGetOrderTimelineAsync(int id)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Unauthorized();
            }

            var order = await _context.Orders
                .FirstOrDefaultAsync(o => o.Id == id && o.RestaurantId == user.Id);

            if (order == null)
            {
                return NotFound();
            }

            var timelineData = new
            {
                OrderId = order.Id,
                OrderNumber = order.Id.ToString().PadLeft(5, '0'),
                OrderDate = order.OrderDate,
                CurrentStatus = order.Status.ToString()
            };

            return new JsonResult(timelineData);
        }
    }
}