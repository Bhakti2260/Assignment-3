using FoodDeliveryApp.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using System.IO;
using FoodDeliveryApp.Database;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using FoodDeliveryApp.Enums;

namespace FoodDeliveryApp.Pages.Admin
{
    [Microsoft.AspNetCore.Authorization.Authorize(Roles = "Admin")]
    public class EditRestaurantModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IWebHostEnvironment _environment;

        public EditRestaurantModel(ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            IWebHostEnvironment environment)
        {
            _context = context;
            _userManager = userManager;
            _environment = environment;
        }

        [BindProperty]
        public InputModel Input { get; set; }

        // Dropdown options for restaurant types (used for Title)
        public List<SelectListItem> RestaurantTypeOptions { get; set; } = new List<SelectListItem>();

        public bool IsEdit { get; set; } = false;

        // Property to hold the existing image path for display in the view
        public string ExistingImagePath { get; set; }

        public class InputModel
        {
            [ValidateNever]
            public string Id { get; set; }

            [Required(ErrorMessage = "Restaurant type is required.")]
            public string Title { get; set; }

            [Required(ErrorMessage = "Restaurant name is required.")]
            public string Name { get; set; }

            [Required, EmailAddress]
            public string Email { get; set; }

            public string PhoneNumber { get; set; }

            public string Address { get; set; }

            public string Description { get; set; }

            // File picker for image upload
            [Display(Name = "Image")]
            [ValidateNever]
            public IFormFile? ImageFile { get; set; }

            // Store the URL of the saved image
            [ValidateNever]
            public string? ImageUrl { get; set; }
        }

        public async Task<IActionResult> OnGetAsync(string id)
        {
            PopulateRestaurantTypeOptions();

            if (!string.IsNullOrEmpty(id))
            {
                // Editing an existing restaurant
                var restaurant = await _context.Set<Entities.Restaurant>().FindAsync(id);
                if (restaurant == null)
                {
                    return NotFound();
                }
                IsEdit = true;
                Input = new InputModel
                {
                    Id = restaurant.Id,
                    Title = restaurant.Title,
                    Name = restaurant.Name,
                    Email = restaurant.Email,
                    PhoneNumber = restaurant.PhoneNumber,
                    Address = restaurant.Address,
                    Description = restaurant.Description,
                    ImageUrl = restaurant.ImageUrl
                };

                // Set the existing image path for display
                ExistingImagePath = restaurant.ImageUrl;
            }
            else
            {
                // Adding a new restaurant
                IsEdit = false;
                Input = new InputModel();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            PopulateRestaurantTypeOptions();

            if (!ModelState.IsValid)
            {
                return Page();
            }

            Entities.Restaurant restaurant;
            if (!string.IsNullOrEmpty(Input.Id))
            {
                // Edit existing restaurant
                restaurant = await _context.Set<Entities.Restaurant>().FindAsync(Input.Id);
                if (restaurant == null)
                {
                    return NotFound();
                }

                // Preserve existing image URL if no new image is uploaded
                ExistingImagePath = restaurant.ImageUrl;
            }
            else
            {
                // Create a new restaurant
                restaurant = new Entities.Restaurant
                {
                    UserName = Input.Email, // using email as username
                    Email = Input.Email,
                    Status = RestaurantStatus.Approved // default status when added by admin
                };
                var createResult = await _userManager.CreateAsync(restaurant, "Default@123"); // default password; should be updated by restaurant
                if (!createResult.Succeeded)
                {
                    foreach (var error in createResult.Errors)
                    {
                        ModelState.AddModelError(string.Empty, error.Description);
                    }
                    return Page();
                }
                // Assign the Restaurant role
                await _userManager.AddToRoleAsync(restaurant, "Restaurant");
            }

            // Update properties (common for both add and edit)
            restaurant.Title = Input.Title;
            restaurant.Name = Input.Name;
            restaurant.Email = Input.Email;
            restaurant.PhoneNumber = Input.PhoneNumber;
            restaurant.Address = Input.Address;
            restaurant.Description = Input.Description;

            // Handle image file upload if a file is provided
            if (Input.ImageFile != null && Input.ImageFile.Length > 0)
            {
                // Delete existing image file if there is one
                if (!string.IsNullOrEmpty(restaurant.ImageUrl))
                {
                    var existingFilePath = Path.Combine(_environment.WebRootPath, restaurant.ImageUrl.TrimStart('/'));
                    if (System.IO.File.Exists(existingFilePath))
                    {
                        try
                        {
                            System.IO.File.Delete(existingFilePath);
                        }
                        catch (IOException)
                        {
                            // Log error or handle if needed
                        }
                    }
                }

                // Determine the folder path: wwwroot/images/restaurants
                var folderPath = Path.Combine(_environment.WebRootPath, "images", "restaurants");
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                // Validate file is an image
                string[] permittedExtensions = { ".jpg", ".jpeg", ".png", ".gif" };
                var ext = Path.GetExtension(Input.ImageFile.FileName).ToLowerInvariant();

                if (string.IsNullOrEmpty(ext) || !permittedExtensions.Contains(ext))
                {
                    ModelState.AddModelError("Input.ImageFile", "Please upload a valid image file (jpg, jpeg, png, gif)");
                    return Page();
                }

                // Create a unique filename using a GUID
                var fileName = Guid.NewGuid().ToString() + ext;
                var filePath = Path.Combine(folderPath, fileName);

                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await Input.ImageFile.CopyToAsync(fileStream);
                }

                // Set the ImageUrl property to the relative URL for use in the app
                restaurant.ImageUrl = $"/images/restaurants/{fileName}";
            }

            _context.Update(restaurant);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Manage");
        }

        /// <summary>
        /// Populates a fixed list of restaurant types.
        /// </summary>
        private void PopulateRestaurantTypeOptions()
        {
            RestaurantTypeOptions = new List<SelectListItem>
            {
                new SelectListItem { Value = "Fast Food", Text = "Fast Food" },
                new SelectListItem { Value = "Casual Dining", Text = "Casual Dining" },
                new SelectListItem { Value = "Fine Dining", Text = "Fine Dining" },
                new SelectListItem { Value = "Cafe", Text = "Cafe" },
                new SelectListItem { Value = "Buffet", Text = "Buffet" },
                new SelectListItem { Value = "Food Truck", Text = "Food Truck" }
            };
        }
    }
}