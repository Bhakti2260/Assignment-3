using FoodDeliveryApp.Database;
using FoodDeliveryApp.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace FoodDeliveryApp.Pages.Admin.Restaurants
{
    [Authorize(Roles = "Admin")]
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<Entities.Restaurant> Restaurants { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            // Query all restaurants (records with the discriminator "Restaurant")
            Restaurants = await _context.Set<Entities.Restaurant>().ToListAsync();
            return Page();
        }

        // Handler for soft delete (updates status to Blocked)
        public async Task<IActionResult> OnPostDeleteAsync(string id)
        {
            var restaurant = await _context.Set<Entities.Restaurant>().FindAsync(id);
            if (restaurant != null)
            {
                restaurant.Status = RestaurantStatus.Blocked;
                _context.Update(restaurant);
                await _context.SaveChangesAsync();
            }
            return RedirectToPage();
        }
    }
}
