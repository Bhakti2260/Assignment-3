using FoodDeliveryApp.Database;
using FoodDeliveryApp.Entities;
using FoodDeliveryApp.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace FoodDeliveryApp.Pages.Allergens
{
    [Authorize(Roles = "Admin")]

    public class EditModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public EditModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public InputModel Input { get; set; }
        public bool IsEdit { get; set; } = false;

        public class InputModel
        {
            public int Id { get; set; }

            [Required(ErrorMessage = "Name is required.")]
            public string Name { get; set; }

            public string Description { get; set; }

            [Required]
            public AllergenStatus Status { get; set; } = AllergenStatus.Pending;
        }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id.HasValue)
            {
                var allergen = await _context.Allergens.FindAsync(id.Value);
                if (allergen == null)
                {
                    return NotFound();
                }
                IsEdit = true;
                Input = new InputModel
                {
                    Id = allergen.Id,
                    Name = allergen.Name,
                    Description = allergen.Description,
                    Status = allergen.Status
                };
            }
            else
            {
                Input = new InputModel();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            Allergen allergen;
            if (Input.Id > 0)
            {
                // Update existing allergen
                allergen = await _context.Allergens.FindAsync(Input.Id);
                if (allergen == null)
                {
                    return NotFound();
                }
            }
            else
            {
                // Create a new allergen entry
                allergen = new Allergen();
                _context.Allergens.Add(allergen);
            }

            allergen.Name = Input.Name;
            allergen.Description = Input.Description;
            allergen.Status = Input.Status;

            await _context.SaveChangesAsync();
            return RedirectToPage("Index");
        }
    }
}
