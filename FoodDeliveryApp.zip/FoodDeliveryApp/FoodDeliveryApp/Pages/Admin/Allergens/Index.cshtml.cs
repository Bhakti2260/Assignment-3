using FoodDeliveryApp.Database;
using FoodDeliveryApp.Entities;
using FoodDeliveryApp.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace FoodDeliveryApp.Pages.Allergens
{
    [Authorize(Roles = "Admin")]
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Allergen> Allergens { get; set; }

        public async Task OnGetAsync()
        {
            Allergens = await _context.Allergens.ToListAsync();
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            var allergen = await _context.Allergens.FindAsync(id);
            if (allergen != null)
            {
                _context.Allergens.Remove(allergen);
                await _context.SaveChangesAsync();
            }
            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostApproveAsync(int id)
        {
            var allergen = await _context.Allergens.FindAsync(id);
            if (allergen != null && allergen.Status == AllergenStatus.Pending)
            {
                allergen.Status = AllergenStatus.Approved;
                _context.Allergens.Update(allergen);
                await _context.SaveChangesAsync();
            }
            return RedirectToPage();
        }
    }
}
