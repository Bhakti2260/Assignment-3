﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

public static class ExceptionMiddlewareExtensions
{
    public static void ConfigureCustomExceptionMiddleware(this IApplicationBuilder app)
    {
        app.UseExceptionHandler(appError =>
        {
            appError.Run(async context =>
            {
                context.Response.ContentType = "application/json";
                context.Response.StatusCode = 500;

                var contextFeature = context.Features.Get<IExceptionHandlerFeature>();
                if (contextFeature != null)
                {
                    var responseObj = new
                    {
                        status = context.Response.StatusCode,
                        error = contextFeature.Error.GetType().Name,
                        message = contextFeature.Error.Message
                    };

                    var json = JsonConvert.SerializeObject(responseObj);
                    await context.Response.WriteAsync(json);
                }
            });
        });
    }
}
