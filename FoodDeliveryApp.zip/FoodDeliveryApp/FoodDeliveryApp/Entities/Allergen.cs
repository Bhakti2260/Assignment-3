﻿using FoodDeliveryApp.Enums;
using System.ComponentModel.DataAnnotations;

namespace FoodDeliveryApp.Entities
{
    public class Allergen
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public string Description { get; set; }

        // The status starts as Pending when requested by a user.
        public AllergenStatus Status { get; set; } = AllergenStatus.Pending;

        public ICollection<MenuItem> MenuItems { get; set; } = new List<MenuItem>();

    }
}
