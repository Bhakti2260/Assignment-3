﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FoodDeliveryApp.Entities
{
    public class MenuItem
    {
        public int Id { get; set; }

        // Foreign key linking the menu item to its Restaurant (which is an ApplicationUser)
        [Required]
        public string RestaurantId { get; set; }
        public Restaurant Restaurant { get; set; }

        [Required]
        public string Name { get; set; }

        public string Description { get; set; }

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal Price { get; set; }

        public bool IsPetFriendly { get; set; }

        public string? ImageUrl { get; set; }

        public ICollection<Allergen> Allergens { get; set; } = new List<Allergen>();

        public bool IsDeleted { get; set; } = false;
    }
}
