﻿using FoodDeliveryApp.Enums;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace FoodDeliveryApp.Entities
{
    public class Order
    {
        public int Id { get; set; }

        // Foreign key to the customer (assumes ApplicationUser holds customer data)
        [Required]
        public string CustomerId { get; set; }
        public ApplicationUser Customer { get; set; }

        // Foreign key to the restaurant that will fulfill the order
        [Required]
        public string RestaurantId { get; set; }
        public Restaurant Restaurant { get; set; }

        public DateTime OrderDate { get; set; } = DateTime.UtcNow;

        [JsonConverter(typeof(JsonStringEnumConverter))]
        public OrderStatus Status { get; set; } = OrderStatus.Pending;

        // A collection of order items in this order
        [JsonIgnore]
        public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
    }

}
