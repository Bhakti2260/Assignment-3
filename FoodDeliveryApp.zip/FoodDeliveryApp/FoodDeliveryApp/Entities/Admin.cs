﻿namespace FoodDeliveryApp.Entities
{
    public class Admin : ApplicationUser
    {

    }

}
