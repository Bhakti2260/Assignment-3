﻿using FoodDeliveryApp.Enums;

namespace FoodDeliveryApp.Entities
{
    public class Restaurant : ApplicationUser
    {
        public string Description { get; set; }
        public float Rating { get; set; } = 0;

        public int RatingCount { get; set; } = 0;

        public string ImageUrl { get; set; }

        public string Title { get; set; }

        public string City { get; set; }

        public RestaurantStatus Status { get; set; } = RestaurantStatus.Pending;


    }
}
